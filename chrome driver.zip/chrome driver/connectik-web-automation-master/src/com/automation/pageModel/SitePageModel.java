package com.automation.pageModel;

import com.automation.util.ApplicationUtility;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.api.DesktopScreenRegion;
import org.sikuli.api.ImageTarget;
import org.sikuli.api.ScreenRegion;
import org.sikuli.api.Target;
import org.sikuli.api.robot.Keyboard;
import org.sikuli.api.robot.Mouse;
import org.sikuli.api.robot.desktop.DesktopKeyboard;
import org.sikuli.api.robot.desktop.DesktopMouse;
import org.testng.Assert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

//import java.util.NoSuchElementException;


public class SitePageModel {

    public static void implicitlyWait(WebDriver driver, int waitForSecond) {
        driver.manage().timeouts()
                .implicitlyWait(waitForSecond, TimeUnit.SECONDS);
    }

    /**
     * use this method to enter text into text fields. first clears and then
     * sends keys.
     *
     * @param by   element location
     * @param text text message information
     */
    public static void enterText(WebDriver driver, By by, String text) {
        driver.findElement(by).clear();
        driver.findElement(by).sendKeys(text);
    }

    /**
     * waits up to few seconds to perform action.
     */
    public static void waitFor(double second) {
        try {
            Thread.sleep((int) (1000 * second));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String randomPhoneNumber(WebDriver driver) {

        final String AB = "0123456789";
        Random rnd = new Random();

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            sb.append(AB.charAt(rnd.nextInt(AB.length())));
        }
        String randomPhoneNumber = "+8801444" + sb.toString();
        return randomPhoneNumber;
    }

    public static String randomPhoneCode(WebDriver driver) {

        final String AB = "0123456789";
        Random rnd = new Random();

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            sb.append(AB.charAt(rnd.nextInt(AB.length())));
        }
        String randomPhoneCode = sb.toString();
        return randomPhoneCode;
    }

    public static String randomStringGenerator(WebDriver driver) {

        final String AB = "0123456789";
        Random rnd = new Random();

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++)
            sb.append(AB.charAt(rnd.nextInt(AB.length())));
        return sb.toString();
    }

    public static void selectOptionsVal(WebDriver driver, WebElement element,
                                        String strOptText) {

        List<WebElement> options = element.findElements(By.tagName("option"));

        for (WebElement option : options) {
            if (option.getText().equals(strOptText)) {
                option.click();
                break;
            }
        }
    }

    public static String maskLoginCodes(WebDriver driver) {

        Date now = new Date();
        String timeStamp = new SimpleDateFormat("d").format(now);

        int intSystemTime = ApplicationUtility
                .getDecimalFromStringText(timeStamp);
        int maskCode = 112232 - 10 * intSystemTime;

        String strmaskCode = Integer.toString(maskCode);
        return strmaskCode;
    }

    public static boolean conditionalWait(WebDriver driver,
                                          WebElement supplied, long second) {

        WebDriverWait wait = new WebDriverWait(driver, second);
        WebElement element = wait.until(ExpectedConditions
                .elementToBeClickable(supplied));
        return true;
    }

    public static WebElement conditionalWait2(WebDriver driver, By by,
                                              long second) {

        WebDriverWait wait = new WebDriverWait(driver, second);
        WebElement element = wait.until(ExpectedConditions
                .elementToBeClickable(by));

        return element;
    }

    public static boolean doesElementExist(WebDriver driver,
                                           List<WebElement> element) {
        return element.size() != 0;
    }

    public void waitForVisibilityOf(WebDriver driver, By locator) {

        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));

    }

    public static void waitForVisibilityByElement(WebDriver driver,
                                                  WebElement element) {

        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOf(element));

    }

    public static void waitForElementToBeSelected(WebDriver driver,
                                                  WebElement element) {

        WebDriverWait wait = new WebDriverWait(driver, 30);
        // wait.until(ExpectedConditions.visibilityOf(element));

        wait.until(ExpectedConditions.elementToBeSelected(element));
        // wait.until(ExpectedConditions.);

    }

    public static void waitForClickabilityByElementCustomTime(WebDriver driver,
                                                              WebElement element, int time) {
        WebDriverWait wait = new WebDriverWait(driver, time);
        wait.until(ExpectedConditions.elementToBeClickable(element)).click();
    }

    public static void assertElementIsNotPresented(WebDriver driver,
                                                   WebElement element) {
        try {
            waitForVisibilityByElement(driver, element);
            Assert.assertTrue(false, "unexpected element is presented");
        } catch (Exception e) {
            Assert.assertTrue(true);
        }
    }

    public static void waitForClickabilityByElement(WebDriver driver,
                                                    WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public static void waitForInvisibleByElement(WebDriver driver, By by) {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
    }

    public static void clickButtonByEnterKey(WebDriver driver, By by)
            throws AWTException {

        driver.findElement(by).sendKeys(Keys.ENTER);

    }

    public static void isElememtEnabled(WebDriver driver, By by) {

        driver.findElement(by).isEnabled();
    }

    public static void clickButtonByRobotClass() throws AWTException {

        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
    }

    public static void clearTextField(WebDriver driver, By by) {

        driver.findElement(by).clear();
    }

    public static void navigateToSpecificPage(WebDriver driver, String url) {

        driver.navigate().to(url);
    }

    public static String parseCountryCode(String countryCode) {

        String string = countryCode;
        int left = string.indexOf("(");
        int right = string.indexOf(")");

        // pull out the text inside the parens
        String sub = string.substring(left + 1, right); //
        return sub;

        // System.out.println(sub);

    }

    public static void scrollDownOfPage(WebDriver driver) {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        // jse.executeScript("scroll(0, 750)"); //y value '250' can be altered
        // jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        jse.executeScript("window.scrollTo(0, document.body.scrollHeight)", "");
        // ((JavascriptExecutor) driver).executeScript(
        // "arguments[0].scrollIntoView();", element);
    }

    public static void scrollDownOfPage(WebDriver driver, WebElement element) {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        // jse.executeScript("scroll(0, 750)"); //y value '250' can be altered
        // jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        jse.executeScript("window.scrollTo(0, document.body.scrollHeight)",
                element);
        // ((JavascriptExecutor) driver).executeScript(
        // "arguments[0].scrollIntoView();", element);
    }

    public static void scrollDownOfPageElement(WebDriver driver, WebElement element) {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("arguments[0].scrollIntoView();", element);
    }

    public static String switchTab(WebDriver driver) {
        String URLAfterSwitch = null;
        Set<String> windows = driver.getWindowHandles();
        String mainwindow = driver.getWindowHandle();

        for (String handle : windows) {
            driver.switchTo().window(handle);
            URLAfterSwitch = driver.getCurrentUrl();

        }
       driver.close();
        SitePageModel.waitFor(4);
        driver.switchTo().window(mainwindow);
        // System.out.println(URLAfterSwitch);
        return URLAfterSwitch;

    }

    public static void clickLocationBySikuli(String strLocationImage) {

        ScreenRegion screen = new DesktopScreenRegion();
        Mouse mouse = new DesktopMouse();
        //tell Sikuli which part of the desktop it should target
        Target target = new ImageTarget(new File(strLocationImage));
        BufferedImage bImage = screen.capture();
        //target the region
        ScreenRegion region = screen.find(target);
        //click on the center of it
        mouse.click(region.getCenter());
    }


    public static void typeImagePathBySikuli(String strInputTextImage,
                                             String strTargetImage) {

        ScreenRegion screen = new DesktopScreenRegion();
        Mouse mouse = new DesktopMouse();
        Keyboard kb = new DesktopKeyboard();

        Target target = new ImageTarget(new File(strInputTextImage));

        ScreenRegion region = screen.find(target);
        mouse.click(region.getCenter());

        kb.type(strTargetImage);
    }

    public static String getCurrentURL(WebDriver driver){

        //driver.navigate().to("https://dev-members-ken.rc-app.com/");
        String currentURL= driver.getCurrentUrl();

        // if (currentURL.contains("https://dev-members-ken.rc-app.com/")){

        // }
        return currentURL;

    }
}
