package com.automation.suite;

import com.automation.testClasses.*;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.awt.*;

import static com.automation.testClasses.RCKenya_CheckURL.checkCurrentURL;
import static com.automation.testClasses.RCKenya_CheckURL.checkCurrentStatus;


public class TestSuite_RCKenya_Login extends TestHelper {

    @Parameters({"staffUser"})
    @Test
    @TestInfo(tcName = "Existing User login", feature = "Login", expectedResult = "Existing user has logged in successfully.")
    public void tc_POS_4624_RCRegisteredUserLogin(@Optional("staff") String staffUser) throws InterruptedException, AWTException {

        new RCKenya_CheckURL(driver)
                .checkCurrentStatus(staffUser)  ;

        if (checkCurrentStatus(staffUser).equals("loginPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();
        }

        if (checkCurrentStatus(staffUser).equals("otherPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .openUserMenu()
                    .assertUserMenu()
                    .selectLogout()
                    .assertSelectLogout()
                    .clickLogoutConfirm();

            new RCKenya_SiteLaunch(driver)
                    .assertTreePOPup();
        }

        new RCKenya_SiteLaunch(driver)
                .assertTreePOPup()
                .treePopUpClose();

         new RCKenya_EnterPhoneNumber(driver, staffUser)
                .assertPhoneNumberPage()
                .assertLoginButtonIsDisabled()
                .assertPhoneNumberFieldActive()
                .enterFullPhoneNumber()
                .assertLoginButtonActive()
                .submitLoginInfoByClick();

        new RCKenya_PhoneNumberConfirm(driver, staffUser)
                .assertPhoneNumberConfirm()
                .confirmLoginInfoByEnter();

        new RCKenya_PhoneCode(driver)
                .assertPhoneCode()
                .enterPhoneCode();

        new RCKenya_HomePage(driver)
                .assertHomePage();
    }

    @Parameters({"staffUser"})
    @Test
    @TestInfo(tcName = "Existing User login", feature = "Login", expectedResult = "Existing user has logged in successfully without selecting country code.")
    public void tc_POS_4891_LoginWithoutSelectingCountryCode(@Optional("staff") String staffUser) throws InterruptedException, AWTException {


        new RCKenya_CheckURL(driver)
                .checkCurrentStatus(staffUser)  ;

        if (checkCurrentStatus(staffUser).equals("loginPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();
        }

        if (checkCurrentStatus(staffUser).equals("otherPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .openUserMenu()
                    .assertUserMenu()
                    .selectLogout()
                    .assertSelectLogout()
                    .clickLogoutConfirm();

            new RCKenya_SiteLaunch(driver)
                    .assertTreePOPup();
        }

        new RCKenya_SiteLaunch(driver)
                .assertTreePOPup()
                .treePopUpClose();

        new RCKenya_EnterPhoneNumber(driver, staffUser)
                .assertPhoneNumberPage()
                .assertLoginButtonIsDisabled()
                .assertPhoneNumberFieldActive()
                .enterFullPhoneNumber()
                .assertLoginButtonActive()
                .submitLoginInfoByEnter();

        new RCKenya_PhoneNumberConfirm(driver, staffUser)
                .assertPhoneNumberConfirm()
                .confirmLoginInfoByEnter();

        new RCKenya_PhoneCode(driver)
                .assertPhoneCode()
                .enterPhoneCode();

        new RCKenya_HomePage(driver)
                .assertHomePage();


    }

    @Parameters({"staffUser"})
    @Test
    @TestInfo(tcName = "Existing User login", feature = "Login", expectedResult = "Existing user has logged in successfully after verifying invalid code.")
    public void tc_POS_4964_VerifyInvalidCode(@Optional("staff") String staffUser) throws InterruptedException, AWTException {

        new RCKenya_CheckURL(driver)
                .checkCurrentStatus(staffUser)  ;

        if (checkCurrentStatus(staffUser).equals("loginPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();
        }

        if (checkCurrentStatus(staffUser).equals("otherPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .openUserMenu()
                    .assertUserMenu()
                    .selectLogout()
                    .assertSelectLogout()
                    .clickLogoutConfirm();

            new RCKenya_SiteLaunch(driver)
                    .assertTreePOPup();
        }

        new RCKenya_SiteLaunch(driver)
                .assertTreePOPup()
                .treePopUpClose();

        new RCKenya_EnterPhoneNumber(driver, staffUser)
                .assertPhoneNumberPage()
                .assertLoginButtonIsDisabled()
                .assertPhoneNumberFieldActive()
                .selectCountry()
                .assertSelectCountry()
                .assertLoginButtonIsDisabled()
                .enterPhoneNumber()
                .assertLoginButtonActive()
                .submitLoginInfoByEnter();

        new RCKenya_PhoneNumberConfirm(driver, staffUser)
                .assertPhoneNumberConfirm()
                .confirmLoginInfoByEnter();

        new RCKenya_PhoneCode(driver)
                .assertPhoneCode()
                .enterWrongPhoneCode()
                .assertWrongPhoneCode()
                .enterPhoneCode();

        new RCKenya_HomePage(driver)
                .assertHomePage();

//        tc_POS_5020_Logout(staffUser);
    }

    @Parameters({"staffUser"})
    @Test
    @TestInfo(tcName = "Logout", feature = "Login", expectedResult = "User is able to logout by clicking the link from the 'User menu'")
    public void tc_POS_5020_Logout(@Optional("staff") String staffUser) throws InterruptedException, AWTException{


        new RCKenya_CheckURL(driver)
                .checkCurrentURL(staffUser);

        if (checkCurrentURL(staffUser).equals("loginPage")) {
            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage()
                    .assertTreePOPup()
                    .treePopUpClose();

            new RCKenya_EnterPhoneNumber(driver, staffUser)
                    .assertPhoneNumberPage()
                    .assertLoginButtonIsDisabled()
                    .assertPhoneNumberFieldActive()
                    .enterFullPhoneNumber()
                    .assertLoginButtonActive()
                    .submitLoginInfoByClick();

            new RCKenya_PhoneNumberConfirm(driver, staffUser)
                    .assertPhoneNumberConfirm()
                    .confirmLoginInfoByEnter();

            new RCKenya_PhoneCode(driver)
                    .assertPhoneCode()
                    .enterPhoneCode();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .clickCreateNew();
        }

        new RCKenya_HomePage(driver)
                .assertHomePage()
                .openUserMenu()
                .assertUserMenu()
                .selectLogout()
                .assertSelectLogout()
                .clickLogoutConfirm();

        new RCKenya_SiteLaunch(driver)
                .assertTreePOPup()
                .checkUnauthorized()
                .assertTreePOPup();
    }

    @Parameters({"guestUser"})
    @Test
    @TestInfo(tcName = "Guest user login", feature = "Login", expectedResult = "Existing user is able to authorize as a GUEST with valid phone number")
    public void tc_POS_4892_GuestUserLoginFirstTime(@Optional("guest") String guestUser) throws InterruptedException, AWTException {

        new RCKenya_CheckURL(driver)
                .checkCurrentStatus(guestUser)  ;

        if (checkCurrentStatus(guestUser).equals("loginPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();
        }

        if (checkCurrentStatus(guestUser).equals("otherPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .openUserMenu()
                    .assertUserMenu()
                    .selectLogout()
                    .assertSelectLogout()
                    .clickLogoutConfirm();

            new RCKenya_SiteLaunch(driver)
                    .assertTreePOPup();
        }

        new RCKenya_SiteLaunch(driver)
                .assertTreePOPup()
                .treePopUpClose();

        new RCKenya_EnterPhoneNumber(driver, guestUser)
                .assertPhoneNumberPage()
                .assertLoginButtonIsDisabled()
                .selectCountry()
                .assertSelectCountry()
                .assertPhoneNumberFieldActive()
                .assertLoginButtonIsDisabled()
                .enterPhoneNumber()
                .assertLoginButtonActive()
                .submitPhoneInfo();

        new RCKenya_PhoneNumberConfirm(driver, guestUser)
                .assertPhoneNumberConfirm()
                .phoneNumberConfirm();

        new RCKenya_PhoneCode(driver)
                .assertPhoneCode()
                .enterPhoneCode();

        new RCKenya_MembershipPage(driver)
                .assertMemberShipPage();

//        tc_POS_5020_Logout(guestUser);
    }


    @Parameters({"guestUser"})
    @Test
    @TestInfo(tcName = "Edit Phone number", feature = "Login", expectedResult = "User is able to edit his phone number'")
    public void tc_POS_4895_editPhoneNumber(@Optional("guest") String guestUser) throws InterruptedException, AWTException {

        new RCKenya_CheckURL(driver)
                .checkCurrentStatus(guestUser)  ;

        if (checkCurrentStatus(guestUser).equals("loginPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();
        }

        if (checkCurrentStatus(guestUser).equals("otherPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .openUserMenu()
                    .assertUserMenu()
                    .selectLogout()
                    .assertSelectLogout()
                    .clickLogoutConfirm();

            new RCKenya_SiteLaunch(driver)
                    .assertTreePOPup();
        }

        new RCKenya_SiteLaunch(driver)
                .assertTreePOPup()
                .treePopUpClose();

        new RCKenya_EnterPhoneNumber(driver, guestUser)
                .assertPhoneNumberPage()
                .assertLoginButtonIsDisabled()
                .enterRandomCorrectPhoneNumber()
                .assertLoginButtonActive()
                .submitPhoneInfo();

        new RCKenya_PhoneNumberConfirm(driver, guestUser)
                .assertRandomPhoneNumber()
                .editPhoneNumber();
        new RCKenya_EnterPhoneNumber(driver, guestUser)
                .assertPhoneNumberPage()
                .assertPhoneNumberFieldActive()
                .enterFullPhoneNumber()
                .assertLoginButtonActive()
                .submitPhoneInfo();

        new RCKenya_PhoneNumberConfirm(driver, guestUser)
                .assertPhoneNumberConfirm()
                .phoneNumberConfirm();

        new RCKenya_PhoneCode(driver)
                .assertPhoneCode()
                .enterPhoneCode();

        new RCKenya_HomePage(driver)
                .assertHomePage();
    }

    @Parameters({"staffUser"})
    @Test
    @TestInfo(tcName = "Login using Voice Call", feature = "Login", expectedResult = "User is able to get verification code for authorization via phone voice call")
    public void tc_POS_4960_LoginUsingVoiceCall(@Optional("staff") String staffUser) throws InterruptedException, AWTException {

        new RCKenya_CheckURL(driver)
                .checkCurrentStatus(staffUser)  ;

        if (checkCurrentStatus(staffUser).equals("loginPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();
        }

        if (checkCurrentStatus(staffUser).equals("otherPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .openUserMenu()
                    .assertUserMenu()
                    .selectLogout()
                    .assertSelectLogout()
                    .clickLogoutConfirm();

            new RCKenya_SiteLaunch(driver)
                    .assertTreePOPup();
        }

        new RCKenya_SiteLaunch(driver)
                .assertTreePOPup()
                .treePopUpClose();

        new RCKenya_EnterPhoneNumber(driver, staffUser)
                .assertPhoneNumberPage()
                .assertLoginButtonIsDisabled()
                .enterFullPhoneNumber()
                .assertLoginButtonActive()
                .submitLoginInfoByClick();

        new RCKenya_PhoneNumberConfirm(driver, staffUser)
                .assertPhoneNumberConfirm()
                .phoneNumberConfirm();

        new RCKenya_PhoneCode(driver)
                .assertPhoneCode()
                .clickVoiceVerificationLink();

        new RCKenya_VoiceCallCode(driver)
                .assertVoiceCodePage()
                .clickCallMeButton()
                .enterVoiceCode();

        new RCKenya_HomePage(driver)
                .assertHomePage();

//		tc_POS_5020_Logout(staffUser);
    }

    @Parameters({"guestUser"})
    @Test
    @TestInfo(tcName = "Edit Phone number", feature = "Login", expectedResult = "User is able to edit his phone number'")
    public void tc_POS_4893_absenceofPhoneNumber(@Optional("guest") String guestUser) throws InterruptedException, AWTException {

        new RCKenya_CheckURL(driver)
                .checkCurrentStatus(guestUser)  ;

        if (checkCurrentStatus(guestUser).equals("loginPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();
        }

        if (checkCurrentStatus(guestUser).equals("otherPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .openUserMenu()
                    .assertUserMenu()
                    .selectLogout()
                    .assertSelectLogout()
                    .clickLogoutConfirm();

            new RCKenya_SiteLaunch(driver)
                    .assertTreePOPup();
        }

        new RCKenya_SiteLaunch(driver)
                .navigateToHomePage()
                .assertTreePOPup()
                .treePopUpClose();

        new RCKenya_EnterPhoneNumber(driver, guestUser)
                .assertPhoneNumberPage()
                .assertLoginButtonIsDisabled();
    }

    @Parameters({"newUser"})
    @Test
    @TestInfo(tcName = "skip buying Membership plan from web", feature = "Login", expectedResult = "User is able to skip buying Membership plan from web")
    public void tc_POS_3287_LoginAsNewUser(@Optional("firstuser") String newUser) throws InterruptedException, AWTException {

        new RCKenya_CheckURL(driver)
                .checkCurrentStatus(newUser)  ;

        if (checkCurrentStatus(newUser).equals("loginPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();
        }

        if (checkCurrentStatus(newUser).equals("otherPage")) {

            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .openUserMenu()
                    .assertUserMenu()
                    .selectLogout()
                    .assertSelectLogout()
                    .clickLogoutConfirm();

            new RCKenya_SiteLaunch(driver)
                    .assertTreePOPup();
        }

        new RCKenya_SiteLaunch(driver)
                .assertTreePOPup()
                .treePopUpClose();

        new RCKenya_EnterPhoneNumber(driver, newUser)
                .assertPhoneNumberPage()
                .assertLoginButtonIsDisabled()
                .assertPhoneNumberFieldActive()
                .enterFullPhoneNumber()
                .assertLoginButtonActive()
                .submitLoginInfoByEnter();

        new RCKenya_PhoneNumberConfirm(driver, newUser)
                .assertPhoneNumberConfirm()
                .confirmLoginInfoByEnter();

        new RCKenya_PhoneCode(driver)
                .assertPhoneCode()
                .enterPhoneCodeFirstLogin();

        new RCKenya_RegisterProfile(driver)
                .assertRegistrationProfilePage()
                .enterRequiredField()
                .assertDoneButton()
                .clickDoneButton();

        new RCKenya_MembershipPage(driver)
                .assertNewUserMemberShipPage()
                .clickContinueAsGuestLink();

        new RCKenya_HomePage(driver)
                .assertHomePage();
    }
}