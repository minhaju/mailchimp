package com.automation.suite;

import com.automation.testClasses.*;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.awt.*;
import java.io.IOException;

import static com.automation.testClasses.RCKenya_CheckURL.checkCurrentURL;

public class TestSuite_RCKenya_GiveBlood extends TestHelper {

    @Parameters({"createGiveBloodInfo", "staffUser"})
    @Test
    @TestInfo(tcName = "Check ability to cancel creation of Give Blood Center", feature = "Cancel Create Give Blood Center", expectedResult = "GB center creation window is closed")
    public void tc_POS_4613_CancelCreateGiveBlood(@Optional("givebloodcreate.conf") String createGiveBloodInfo, @Optional("staff") String staffUser) throws InterruptedException, AWTException {

        new RCKenya_CheckURL(driver)
                .checkCurrentURL(staffUser);

        if (checkCurrentURL(staffUser).equals("loginPage")) {
            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage()
                    .assertTreePOPup()
                    .treePopUpClose();

            new RCKenya_EnterPhoneNumber(driver, staffUser)
                    .assertPhoneNumberPage()
                    .assertLoginButtonIsDisabled()
                    .assertPhoneNumberFieldActive()
                    .enterFullPhoneNumber()
                    .assertLoginButtonActive()
                    .submitLoginInfoByClick();

            new RCKenya_PhoneNumberConfirm(driver, staffUser)
                    .assertPhoneNumberConfirm()
                    .confirmLoginInfoByEnter();

            new RCKenya_PhoneCode(driver)
                    .assertPhoneCode()
                    .enterPhoneCode();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .clickCreateNew();
        }

        if (checkCurrentURL(staffUser).equals("otherPage")) {
            new RCKenya_HomePage(driver)
                    .navigateToHomeURL()
                    .assertHomePage()
                    .clickCreateNew();
        }


        new RCKenya_CreateBloodPage(driver, createGiveBloodInfo)
                .assertCreateMenuItemGiveBlood()
                .selectMenuItemGiveBlood()
                .assertCreateMenuItemGiveBloodPage()
                .enterRequiredFieldData()
                .assertGiveBloodPageAfterEnterRequiredField()
                .enterOtherData()
                .clickCancel();
        new RCKenya_HomePage(driver)
                .assertHomePage();

    }


    @Parameters({"createGiveBloodInfo", "staffUser"})
    @Test
    @TestInfo(tcName = " create Give Blood Center item only with filled required field ", feature = "Create Give Blood Center", expectedResult = "GB center is created and opened in detail view")
    public void tc_POS_4612_CreateBlood(@Optional("givebloodcreate.conf") String createGiveBloodInfo, @Optional("staff") String staffUser) throws InterruptedException, AWTException, IOException {

        new RCKenya_CheckURL(driver)
                .checkCurrentURL(staffUser);

        if (checkCurrentURL(staffUser).equals("loginPage")) {
            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage()
                    .assertTreePOPup()
                    .treePopUpClose();

            new RCKenya_EnterPhoneNumber(driver, staffUser)
                    .assertPhoneNumberPage()
                    .assertLoginButtonIsDisabled()
                    .assertPhoneNumberFieldActive()
                    .enterFullPhoneNumber()
                    .assertLoginButtonActive()
                    .submitLoginInfoByClick();

            new RCKenya_PhoneNumberConfirm(driver, staffUser)
                    .assertPhoneNumberConfirm()
                    .confirmLoginInfoByEnter();

            new RCKenya_PhoneCode(driver)
                    .assertPhoneCode()
                    .enterPhoneCode();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .clickCreateNew();
        }

        if (checkCurrentURL(staffUser).equals("otherPage")) {
            new RCKenya_HomePage(driver)
                    .navigateToHomeURL()
                    .assertHomePage()
                    .clickCreateNew();
        }


        new RCKenya_CreateBloodPage(driver, createGiveBloodInfo)
                .assertCreateMenuItemGiveBlood()
                .selectMenuItemGiveBlood()
                .assertCreateMenuItemGiveBloodPage()
                .enterRequiredFieldData()
                .assertGiveBloodPageAfterEnterRequiredField()
                .enterOtherData()
                .clickCreateButton();
        new RCKenya_GiveBloodDetailsView(driver, createGiveBloodInfo)
                .assertGiveBloodDetailsViewInfo();

    }

    @Parameters({"editGiveBloodInfo", "createGiveBloodInfo", "staffUser"})
    @Test
    @TestInfo(tcName = "Check ability to edit Give Blood Center created by user", feature = "Edit GB Center", expectedResult = "GB Center is edited")
    // public void tc_POS_4610_OverViewGiveBlood(@Optional("donatedetails")String donateInfo) throws InterruptedException, AWTException{
    public void tc_POS_4614_EditGBCenter(@Optional("givebloodedit.conf") String editGiveBloodInfo, @Optional("givebloodcreate.conf") String createGiveBloodInfo, @Optional("staff") String staffUser) throws InterruptedException, AWTException, IOException {


        new RCKenya_CheckURL(driver)
                .checkCurrentURL(staffUser);

        if (checkCurrentURL(staffUser).equals("loginPage")) {
            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage()
                    .assertTreePOPup()
                    .treePopUpClose();

            new RCKenya_EnterPhoneNumber(driver, staffUser)
                    .assertPhoneNumberPage()
                    .assertLoginButtonIsDisabled()
                    .assertPhoneNumberFieldActive()
                    .enterFullPhoneNumber()
                    .assertLoginButtonActive()
                    .submitLoginInfoByClick();

            new RCKenya_PhoneNumberConfirm(driver, staffUser)
                    .assertPhoneNumberConfirm()
                    .confirmLoginInfoByEnter();

            new RCKenya_PhoneCode(driver)
                    .assertPhoneCode()
                    .enterPhoneCode();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .clickGiveBlood(createGiveBloodInfo);
        }

        if (checkCurrentURL(staffUser).equals("otherPage")) {
            new RCKenya_HomePage(driver)
                    .navigateToHomeURL()
                    .assertHomePage()
                    .clickGiveBlood(createGiveBloodInfo);
        }


        new RCKenya_GiveBloodListView(driver, createGiveBloodInfo)
                .assertGiveBloodListView()
                .clickSearchIcon()
                .assertSearchField()
                .sendSearchKeyWord()
                .assertGiveBloodListView()
                .edit();

        new RCKenya_EditBloodPage(driver, editGiveBloodInfo)
                .assertEditWindow()
                .editFormDataWithoutLink()
                .AssertOtherFieldData()
                .enterOtherData()
                .clickEditButton();


        new RCKenya_GiveBloodListView(driver, editGiveBloodInfo)
                .assertGiveBloodListView()
                .clickSearchIcon()
                .assertSearchField()
                .sendSearchKeyWord()
                .assertListViewAfterEditing();

    }


    @Parameters({"editGiveBloodInfo"})
    @Test
    @TestInfo(tcName = "Check ability to cancel deleting GB Center created by user", feature = "Overview Give Blood list", expectedResult = "GB center editing window is closed")
    // public void tc_POS_4610_OverViewGiveBlood(@Optional("donatedetails")String donateInfo) throws InterruptedException, AWTException{
    public void tc_POS_4616_CancelDeletePopUP(@Optional("givebloodedit.conf") String editGiveBloodInfo) throws InterruptedException, AWTException, IOException {

        new RCKenya_HomePage(driver)
                .navigateToHomeURL()
                .assertHomePage()
                .clickGiveBlood(editGiveBloodInfo);

        new RCKenya_GiveBloodListView(driver, editGiveBloodInfo)
                .assertGiveBloodListView()
                .clickSearchIcon()
                .assertSearchField()
                .sendSearchKeyWord()
                .edit();


        new RCKenya_EditBloodPage(driver, editGiveBloodInfo)
                .assertEditWindow()
                .clickDeleteButton()
                .asserDeletePopuPWindow()
                .CancelDeletePopup();

        new RCKenya_GiveBloodListView(driver, editGiveBloodInfo)
                .assertListViewAfterEditing();


    }

    @Parameters({"editGiveBloodInfo", "staffUser"})
    @Test
    @TestInfo(tcName = "Cancel editing GB Center ", feature = "Overview List View of Give Blood", expectedResult = "Editing operation is canceled")
    // public void tc_POS_4610_OverViewGiveBlood(@Optional("donatedetails")String donateInfo) throws InterruptedException, AWTException{
    public void tc_POS_4617_CancelEditingGBCenter(@Optional("givebloodedit.conf") String editGiveBloodInfo, @Optional("staff") String staffUser) throws InterruptedException, AWTException, IOException {


        new RCKenya_CheckURL(driver)
                .checkCurrentURL(staffUser);

        if (checkCurrentURL(staffUser).equals("loginPage")) {
            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage()
                    .assertTreePOPup()
                    .treePopUpClose();

            new RCKenya_EnterPhoneNumber(driver, staffUser)
                    .assertPhoneNumberPage()
                    .assertLoginButtonIsDisabled()
                    .assertPhoneNumberFieldActive()
                    .enterFullPhoneNumber()
                    .assertLoginButtonActive()
                    .submitLoginInfoByClick();

            new RCKenya_PhoneNumberConfirm(driver, staffUser)
                    .assertPhoneNumberConfirm()
                    .confirmLoginInfoByEnter();

            new RCKenya_PhoneCode(driver)
                    .assertPhoneCode()
                    .enterPhoneCode();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }

        if (checkCurrentURL(staffUser).equals("otherPage")) {
            new RCKenya_HomePage(driver)
                    .navigateToHomeURL()
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }


        new RCKenya_GiveBloodListView(driver, editGiveBloodInfo)
                .assertGiveBloodListView()
                .clickSearchIcon()
                .assertSearchField()
                .sendSearchKeyWord()
                .assertGiveBloodListView()
                .edit();


        new RCKenya_EditBloodPage(driver, editGiveBloodInfo)
                .assertEditWindow()
                .editFormDataWithoutLink()
                .enterOtherData()
                .clickCancelEdit();

        new RCKenya_GiveBloodListView(driver, editGiveBloodInfo)
                .assertListViewAfterEditing();

    }

    @Parameters({"editGiveBloodInfo", "staffUser"})
    @Test
    @TestInfo(tcName = "Overview detail view of Give Blood Center", feature = "Overview Detail View of Give Blood", expectedResult = "GB center is opened in detail view")
    // public void tc_POS_4610_OverViewGiveBlood(@Optional("donatedetails")String donateInfo) throws InterruptedException, AWTException{
    public void tc_POS_4618_OverViewDetailViewGiveBlood(@Optional("givebloodedit.conf") String editGiveBloodInfo, @Optional("staff") String staffUser) throws InterruptedException, AWTException, IOException {


        new RCKenya_CheckURL(driver)
                .checkCurrentURL(staffUser);

        if (checkCurrentURL(staffUser).equals("loginPage")) {
            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage()
                    .assertTreePOPup()
                    .treePopUpClose();

            new RCKenya_EnterPhoneNumber(driver, staffUser)
                    .assertPhoneNumberPage()
                    .assertLoginButtonIsDisabled()
                    .assertPhoneNumberFieldActive()
                    .enterFullPhoneNumber()
                    .assertLoginButtonActive()
                    .submitLoginInfoByClick();

            new RCKenya_PhoneNumberConfirm(driver, staffUser)
                    .assertPhoneNumberConfirm()
                    .confirmLoginInfoByEnter();

            new RCKenya_PhoneCode(driver)
                    .assertPhoneCode()
                    .enterPhoneCode();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }

        if (checkCurrentURL(staffUser).equals("otherPage")) {
            new RCKenya_HomePage(driver)
                    .navigateToHomeURL()
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }


        new RCKenya_GiveBloodListView(driver, editGiveBloodInfo)
                .assertGiveBloodListView()
                .clickSearchIcon()
                .assertSearchField()
                .sendSearchKeyWord()
                .assertGiveBloodListView()
                .openGBCenterDetailsView();

        new RCKenya_GiveBloodDetailsView(driver, editGiveBloodInfo)
                .assertGiveBloodDetailsView();
    }

    @Parameters({"editGiveBloodInfo", "createGiveBloodInfo", "staffUser"})
    @Test
    @TestInfo(tcName = "Edit GB Center from detail view", feature = "Edit GB Center from detail view", expectedResult = "GB center is edited from detail view")
    // public void tc_POS_4610_OverViewGiveBlood(@Optional("donatedetails")String donateInfo) throws InterruptedException, AWTException{
    public void tc_POS_4619_EditGBCenterFromDetailsView(@Optional("givebloodedit.conf") String editGiveBloodInfo, @Optional("givebloodcreate.conf") String createGiveBloodInfo, @Optional("staff") String staffUser) throws InterruptedException, AWTException, IOException {

        new RCKenya_CheckURL(driver)
                .checkCurrentURL(staffUser);

        if (checkCurrentURL(staffUser).equals("loginPage")) {
            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage()
                    .assertTreePOPup()
                    .treePopUpClose();

            new RCKenya_EnterPhoneNumber(driver, staffUser)
                    .assertPhoneNumberPage()
                    .assertLoginButtonIsDisabled()
                    .assertPhoneNumberFieldActive()
                    .enterFullPhoneNumber()
                    .assertLoginButtonActive()
                    .submitLoginInfoByClick();

            new RCKenya_PhoneNumberConfirm(driver, staffUser)
                    .assertPhoneNumberConfirm()
                    .confirmLoginInfoByEnter();

            new RCKenya_PhoneCode(driver)
                    .assertPhoneCode()
                    .enterPhoneCode();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }

        if (checkCurrentURL(staffUser).equals("otherPage")) {
            new RCKenya_HomePage(driver)
                    .navigateToHomeURL()
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }

        // new RCKenya_HomePage(driver)
        ////         .navigateToHomeURL()
        //         .assertHomePage()
        //          .clickGiveBlood(editGiveBloodInfo);

        new RCKenya_GiveBloodListView(driver, createGiveBloodInfo)
                .assertGiveBloodListView()
                .clickSearchIcon()
                .assertSearchField()
                .sendSearchKeyWord()
                .assertGiveBloodListView()
                .openGBCenterDetailsView();

        new RCKenya_GiveBloodDetailsView(driver, editGiveBloodInfo)
                .assertGiveBloodDetailsView()
                .edit();

        new RCKenya_EditBloodPage(driver, editGiveBloodInfo)
                .assertEditWindow()
                .editFormDataWithoutLink()
                .AssertOtherFieldData()
                .enterOtherData()
                .clickEditButton();

        new RCKenya_GiveBloodDetailsView(driver, editGiveBloodInfo)
                .assertGiveBloodDetailsViewAfterEdit();

    }

    @Parameters({"editGiveBloodInfo", "staffUser"})

    @Test
    @TestInfo(tcName = "Check ability to delete Give Blood Center ", feature = "Edit GB Center", expectedResult = "GB Center is deleted")
    // public void tc_POS_4610_OverViewGiveBlood(@Optional("donatedetails")String donateInfo) throws InterruptedException, AWTException{
    public void tc_POS_4615_DeleteGBCenter(@Optional("givebloodedit.conf") String editGiveBloodInfo, @Optional("staff") String staffUser) throws InterruptedException, AWTException, IOException {


        new RCKenya_CheckURL(driver)
                .checkCurrentURL(staffUser);

        if (checkCurrentURL(staffUser).equals("loginPage")) {
            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage()
                    .assertTreePOPup()
                    .treePopUpClose();

            new RCKenya_EnterPhoneNumber(driver, staffUser)
                    .assertPhoneNumberPage()
                    .assertLoginButtonIsDisabled()
                    .assertPhoneNumberFieldActive()
                    .enterFullPhoneNumber()
                    .assertLoginButtonActive()
                    .submitLoginInfoByClick();

            new RCKenya_PhoneNumberConfirm(driver, staffUser)
                    .assertPhoneNumberConfirm()
                    .confirmLoginInfoByEnter();

            new RCKenya_PhoneCode(driver)
                    .assertPhoneCode()
                    .enterPhoneCode();

            new RCKenya_HomePage(driver)
                    .assertHomePage();
        } else {

            new RCKenya_HomePage(driver)
                    .navigateToHomeURL()
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }


        new RCKenya_GiveBloodListView(driver, editGiveBloodInfo)
                .assertGiveBloodListView()
                .clickSearchIcon()
                .assertSearchField()
                .sendSearchKeyWord()
                .assertGiveBloodListView()
                .edit();


        new RCKenya_EditBloodPage(driver, editGiveBloodInfo)
                .assertEditWindow()
                .clickDeleteButton()
                .asserDeletePopuPWindow()
                .clickDeleteConfirmPopup();

        new RCKenya_GiveBloodListView(driver, editGiveBloodInfo)
                .assertNothingFoundText();

    }

    @Parameters({"editGiveBloodInfo", "staffUser"})
    @Test
    @TestInfo(tcName = " Check ability to Navigate to GB Center from list view", feature = "Overview Give Blood list", expectedResult = "Google Map is displayed")
    public void tc_POS_4622_NavigateGBListView(@Optional("givebloodedit.conf") String editGiveBloodInfo, @Optional("staff") String staffUser) throws InterruptedException, AWTException, IOException {


        new RCKenya_CheckURL(driver)
                .checkCurrentURL(staffUser);

        if (checkCurrentURL(staffUser).equals("loginPage")) {
            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage()
                    .assertTreePOPup()
                    .treePopUpClose();

            new RCKenya_EnterPhoneNumber(driver, staffUser)
                    .assertPhoneNumberPage()
                    .assertLoginButtonIsDisabled()
                    .assertPhoneNumberFieldActive()
                    .enterFullPhoneNumber()
                    .assertLoginButtonActive()
                    .submitLoginInfoByClick();

            new RCKenya_PhoneNumberConfirm(driver, staffUser)
                    .assertPhoneNumberConfirm()
                    .confirmLoginInfoByEnter();

            new RCKenya_PhoneCode(driver)
                    .assertPhoneCode()
                    .enterPhoneCode();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }

        if (checkCurrentURL(staffUser).equals("otherPage")) {
            new RCKenya_HomePage(driver)
                    .navigateToHomeURL()
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }


        //new RCKenya_HomePage(driver)
        //        .navigateToHomeURL()
        //      .assertHomePage()
        //       .clickGiveBlood(editGiveBloodInfo);

        new RCKenya_GiveBloodListView(driver, editGiveBloodInfo)
                .assertGiveBloodListView()
                // .clickSearchIcon()
                // .assertSearchField()
                // .sendSearchKeyWord()
                .clickNavigate()
                .assertGoogleMap();

    }

    @Parameters({"createGiveBloodInfo", "staffUser"})
    @Test
    @TestInfo(tcName = "Overview GB Centers on map", feature = "Overview GB Centers on map", expectedResult = "Overview GB Centers on map")
    public void tc_POS_4620_OverViewGBMapView(@Optional("givebloodcreate.conf") String createGiveBloodInfo, @Optional("staff") String staffUser) throws InterruptedException, AWTException, IOException {

        new RCKenya_CheckURL(driver)
                .checkCurrentURL(staffUser);

        if (checkCurrentURL(staffUser).equals("loginPage")) {
            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage()
                    .assertTreePOPup()
                    .treePopUpClose();

            new RCKenya_EnterPhoneNumber(driver, staffUser)
                    .assertPhoneNumberPage()
                    .assertLoginButtonIsDisabled()
                    .assertPhoneNumberFieldActive()
                    .enterFullPhoneNumber()
                    .assertLoginButtonActive()
                    .submitLoginInfoByClick();

            new RCKenya_PhoneNumberConfirm(driver, staffUser)
                    .assertPhoneNumberConfirm()
                    .confirmLoginInfoByEnter();

            new RCKenya_PhoneCode(driver)
                    .assertPhoneCode()
                    .enterPhoneCode();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .clickGiveBlood(createGiveBloodInfo);
        }

        if (checkCurrentURL(staffUser).equals("otherPage")) {
            new RCKenya_HomePage(driver)
                    .navigateToHomeURL()
                    .assertHomePage()
                    .clickGiveBlood(createGiveBloodInfo);
        }


        new RCKenya_GiveBloodListView(driver, createGiveBloodInfo)
                .assertGiveBloodListView()
                .openMapView()
                .assertMapView()
                .clickMapViewPin()
                .assertMapModal()
                .clickViewButton();

        new RCKenya_GiveBloodDetailsView(driver, createGiveBloodInfo)
                .assertGiveBloodDetailsView();


    }

    @Parameters({"editGiveBloodInfo", "staffUser"})
    @Test
    @TestInfo(tcName = " Check ability to Navigate to GB Center from Details view", feature = "Details view Give Blood list", expectedResult = "GoogleMap is displayed")
    public void tc_POS_4621_NavigateGBCenterFromDetailsView(@Optional("givebloodedit.conf") String editGiveBloodInfo, @Optional("staff") String staffUser) throws InterruptedException, AWTException, IOException {


        new RCKenya_CheckURL(driver)
                .checkCurrentURL(staffUser);

        if (checkCurrentURL(staffUser).equals("loginPage")) {
            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage()
                    .assertTreePOPup()
                    .treePopUpClose();

            new RCKenya_EnterPhoneNumber(driver, staffUser)
                    .assertPhoneNumberPage()
                    .assertLoginButtonIsDisabled()
                    .assertPhoneNumberFieldActive()
                    .enterFullPhoneNumber()
                    .assertLoginButtonActive()
                    .submitLoginInfoByClick();

            new RCKenya_PhoneNumberConfirm(driver, staffUser)
                    .assertPhoneNumberConfirm()
                    .confirmLoginInfoByEnter();

            new RCKenya_PhoneCode(driver)
                    .assertPhoneCode()
                    .enterPhoneCode();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }

        if (checkCurrentURL(staffUser).equals("otherPage")) {
            new RCKenya_HomePage(driver)
                    .navigateToHomeURL()
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }
        // new RCKenya_HomePage(driver)
        //         .navigateToHomeURL()
        //     .assertHomePage()
        //    .clickGiveBlood(editGiveBloodInfo);

        new RCKenya_GiveBloodListView(driver, editGiveBloodInfo)
                .assertGiveBloodListView()

                //.clickSearchIcon()
                //.assertSearchField()
                //  .sendSearchKeyWord()
                //  .assertGiveBloodListView()
                .openGBCenterDetailsView();

        new RCKenya_GiveBloodDetailsView(driver, editGiveBloodInfo)
                .assertGiveBloodDetailsView()
                .clickNavigate();

        new RCKenya_GiveBloodMapTab(driver)
                .assertGoogleMap();

    }

    @Parameters({"editGiveBloodInfo", "staffUser"})
    @Test
    @TestInfo(tcName = "Search for Give Blood", feature = "Search Give Blood Center", expectedResult = "Search is performed")
    public void tc_POS_4611_Search(@Optional("givebloodedit.conf") String editGiveBloodInfo, @Optional("staff") String staffUser) throws InterruptedException, AWTException, IOException {


        new RCKenya_CheckURL(driver)
                .checkCurrentURL(staffUser);

        if (checkCurrentURL(staffUser).equals("loginPage")) {
            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage()
                    .assertTreePOPup()
                    .treePopUpClose();

            new RCKenya_EnterPhoneNumber(driver, staffUser)
                    .assertPhoneNumberPage()
                    .assertLoginButtonIsDisabled()
                    .assertPhoneNumberFieldActive()
                    .enterFullPhoneNumber()
                    .assertLoginButtonActive()
                    .submitLoginInfoByClick();

            new RCKenya_PhoneNumberConfirm(driver, staffUser)
                    .assertPhoneNumberConfirm()
                    .confirmLoginInfoByEnter();

            new RCKenya_PhoneCode(driver)
                    .assertPhoneCode()
                    .enterPhoneCode();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }

        if (checkCurrentURL(staffUser).equals("otherPage")) {
            new RCKenya_HomePage(driver)
                    .navigateToHomeURL()
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }


        new RCKenya_GiveBloodListView(driver, editGiveBloodInfo)
                .assertGiveBloodListView()
                .clickSearchIcon()
                .assertSearchField()
                .sendSearchKeyWord()
                .closeSearchIcon()
                .assertGiveBloodListView()
                .clickSearchIcon()
                .assertSearchField()
                .sendSearchKeyWordDescription()
                .openMapView()
                .assertMapView()
                .openListView()
                .assertGiveBloodListView()
                .assertSearchText();

    }

    @Parameters({"editGiveBloodInfo", "staffUser"})
    @Test
    @TestInfo(tcName = "Overview Give Blood list", feature = "Overview Give Blood list view", expectedResult = "List is displayed with Item and scrolled")
    public void tc_POS_4610_OverViewGiveBloodList(@Optional("givebloodedit.conf") String editGiveBloodInfo, @Optional("staff") String staffUser) throws InterruptedException, AWTException, IOException {

        new RCKenya_CheckURL(driver)
                .checkCurrentURL(staffUser);

        if (checkCurrentURL(staffUser).equals("loginPage")) {
            new RCKenya_SiteLaunch(driver)
                    .navigateToHomePage()
                    .assertTreePOPup()
                    .treePopUpClose();

            new RCKenya_EnterPhoneNumber(driver, staffUser)
                    .assertPhoneNumberPage()
                    .assertLoginButtonIsDisabled()
                    .assertPhoneNumberFieldActive()
                    .enterFullPhoneNumber()
                    .assertLoginButtonActive()
                    .submitLoginInfoByClick();

            new RCKenya_PhoneNumberConfirm(driver, staffUser)
                    .assertPhoneNumberConfirm()
                    .confirmLoginInfoByEnter();

            new RCKenya_PhoneCode(driver)
                    .assertPhoneCode()
                    .enterPhoneCode();

            new RCKenya_HomePage(driver)
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }

        if (checkCurrentURL(staffUser).equals("otherPage")) {
            new RCKenya_HomePage(driver)
                    .navigateToHomeURL()
                    .assertHomePage()
                    .clickGiveBlood(editGiveBloodInfo);
        }


        //new RCKenya_HomePage(driver)
        //        .navigateToHomeURL()
        //      .assertHomePage()
        //      .clickGiveBlood(editGiveBloodInfo);

        new RCKenya_GiveBloodListView(driver, editGiveBloodInfo)
                .assertGiveBloodListView()
                .assertCursorPosition()
                .scrollListView()
                .assertGiveBloodListView();

    }

}