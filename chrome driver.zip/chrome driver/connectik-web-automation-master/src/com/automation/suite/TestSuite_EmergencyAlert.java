package com.automation.suite;

import com.automation.testClasses.*;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.awt.*;
import java.io.IOException;

public class TestSuite_EmergencyAlert extends TestHelper {


    @Test
    @TestInfo(tcName = "Overview Emergency Page", feature = "Emergency alert", expectedResult = "Overview of emergency alert loaded successfully.")
    public void tc_POS_4596_EmergencyAlertPage() throws InterruptedException, AWTException, IOException {

        new RCKenya_HomePage(driver)
                .navigateToHomeURL()
                .assertEmergencyTile()
                .clickEmergencyTile();

        new RCKenya_EmergencyAlert_ListViewPage(driver)
                .assertEmergencyAlertListPage()
                .assertEmergencyAlertList()
                .assertPeculiaritiesOfList();
    }

    @Test
    @TestInfo(tcName = "Search Emergency alert", feature = "Emergency alert", expectedResult = "User can search emergency alert successfully.")
    public void tc_POS_4597_SearchEmergencyAlert() throws InterruptedException, AWTException, IOException {

        new RCKenya_HomePage(driver)
                .navigateToHomeURL()
                .assertEmergencyTile()
                .clickEmergencyTile();

        new RCKenya_EmergencyAlert_ListViewPage(driver)
                .assertEmergencyAlertListPage()
                .clickSearchIconFromList()
                .searchByName()
                .assertSearchByName()
                .ClickSearchCrossIcon()
                .clickSearchIconFromList()
                .searchByDescription()
                .assertClickMapListIcon();
    }

    @Parameters({"donateInfo"})
    @Test
    @TestInfo(tcName = "Donate from Emergency alert list", feature = "Emergency alert", expectedResult = "User can donate from emergency alert list successfully.")
    public void tc_POS_4598_DonateFromListPage(@Optional("donatedetails") String donateInfo) throws InterruptedException, AWTException, IOException {

        new RCKenya_HomePage(driver)
                .navigateToHomeURL()
                .assertEmergencyTile()
                .clickEmergencyTile();

        new RCKenya_EmergencyAlert_ListViewPage(driver)
                .clickSearchIconFromList()
                .searchByName()
                .assertEmergencyAlertListPage()
                .donateFromAlertList();

        new RCKenya_Donate(driver, donateInfo)
                .assertDonatePageForEmergencyAlert()
                .hoverQuestionMark()
                .assertToolTipText()
                .enterDonationAmount()
                .assertPaymentMethodField()
                .selectPaymentMethod()
                .assertCardNumberField()
                .enterCardInfo()
                .assertProceedButton()
                .clickProceedButton();

        new RCKenya_DonateConfirm(driver, donateInfo)
                .assertDonateConfirm()
                .clickConfirmButton()
                .assertPaymentComplete();
    }

    @Test
    @TestInfo(tcName = "Emergency alert creation", feature = "Emergency alert", expectedResult = "User can create emergency alert successfully.")
    public void tc_POS_4599_EmergencyAlertCreation() throws InterruptedException, AWTException, IOException {


        new RCKenya_HomePage(driver)
                .navigateToHomeURL()
                .assertNewButton()
                .clickNewButton()
                .openEmergencyAlertCreationForm();

        new RCKenya_EmergencyAlert_CreatePage(driver)
                .fillEmergencyAlertValue()
                .assertEmergencyAlertPostButtonActive()
                .assertHelpToolTip()
                .createEmergencyAlert()
                .assertEmergencyAlertDetailPage();

    }

    @Test
    @TestInfo(tcName = "Cancel Emergency alert creation page", feature = "Emergency alert", expectedResult = "User can cancel emergency alert creation page successfully.")
    public void tc_POS_4600_EmergencyCreationPageCancel() throws InterruptedException, AWTException, IOException {

        new RCKenya_HomePage(driver)
                .navigateToHomeURL()
                .assertNewButton()
                .clickNewButton()
                .openEmergencyAlertCreationForm();

        new RCKenya_EmergencyAlert_CreatePage(driver)
                .fillEmergencyAlertValue()
                .assertEmergencyAlertPostButtonActive()
                .cancelEmergencyCreationForm()
                .assertEmergencyAlertNotCreated();
    }

    @Test
    @TestInfo(tcName = "Cancel Emergency alert creation page", feature = "Emergency alert", expectedResult = "User can cancel emergency alert creation page successfully.")
    public void tc_POS_4601_EditEmergencyAlertFromList() throws InterruptedException, AWTException, IOException {

        new RCKenya_HomePage(driver)
                .navigateToHomeURL()
                .assertNewButton()
                .clickEmergencyTile();

        new RCKenya_EmergencyAlert_ListViewPage(driver)
                .clickSearchIconFromList()
                .searchByName()
                .clickEditButtonFromList();

        new RCKenya_EmergencyAlert_EditPage(driver)
                .assertEmergencyAlertEditButtonActive()
                .editEmergencyAlertInfoFromList();
//          		.assertEditedInfoFromListPage();
    }

    @Test
    @TestInfo(tcName = "Delete Emergency alert", feature = "Emergency alert", expectedResult = "User can delete emergency alert successfully.")
    public void tc_POS_4602_EmergencyAlertDeletion() throws InterruptedException, AWTException, IOException {

        new RCKenya_HomePage(driver)
                .navigateToHomeURL()
                .assertNewButton()
                .clickEmergencyTile();

        new RCKenya_EmergencyAlert_ListViewPage(driver)
                .clickAlertNameFromList();

        new RCKenya_EmergencyAlert_DetailViewPage(driver)
                .clickEditFromDetailPage()
                .clickDeleteButton()
                .assertDeleteConfirm();
    }

    @Test
    @TestInfo(tcName = "Cancel delete Emergency alert window", feature = "Emergency alert", expectedResult = "User can cancel delete emergency alert successfully.")
    public void tc_POS_4603_EmergencyAlertDeletionWindowCancel() throws InterruptedException, AWTException, IOException {

        new RCKenya_HomePage(driver)
                .navigateToHomeURL()
                .assertNewButton()
                .clickEmergencyTile();

        new RCKenya_EmergencyAlert_ListViewPage(driver)
                .clickAlertNameFromList();

        new RCKenya_EmergencyAlert_DetailViewPage(driver)
                .clickEditFromDetailPage()
                .clickDeleteButton()
                .cancelDeleteConfirm();
    }

    @Test
    @TestInfo(tcName = "Cancel edit Emergency alert window", feature = "Emergency alert", expectedResult = "User can cancel edit emergency alert successfully.")
    public void tc_POS_4604_EmergencyAlertEditWindowCancel() throws InterruptedException, AWTException, IOException {

        new RCKenya_HomePage(driver)
                .navigateToHomeURL()
                .assertNewButton()
                .clickEmergencyTile();

        new RCKenya_EmergencyAlert_ListViewPage(driver)
                .clickSearchIconFromList()
                .searchByName()
                .clickAlertNameFromList();

        new RCKenya_EmergencyAlert_DetailViewPage(driver)
                .clickEditFromDetailPage();


        new RCKenya_EmergencyAlert_EditPage(driver)
                .assertEmergencyAlertEditButtonActive()
                .fillEmergencyAlertValue()
                .assertEmergencyAlertEditButtonActive()
                .cancelEmergencyCreationForm()
                .assertEmergencyEditCancel();
    }

    @Test
    @TestInfo(tcName = "Overview Emergency alert detail page", feature = "Emergency alert", expectedResult = "User can see all info on emergency alert detail page correctly.")
    public void tc_POS_4605_OverviewEmergencyAlertDetail() throws InterruptedException, AWTException, IOException {

        new RCKenya_HomePage(driver)
                .navigateToHomeURL()
                .assertNewButton()
                .clickEmergencyTile();

        new RCKenya_EmergencyAlert_ListViewPage(driver)
                .clickSearchIconFromList()
                .searchByName()
                .clickAlertNameFromList();

        new RCKenya_EmergencyAlert_DetailViewPage(driver)
                .getAlertInfoFromDetailPage();
    }

    @Parameters({"donateInfo"})
    @Test
    @TestInfo(tcName = "Donate from Emergency alert window", feature = "Emergency alert", expectedResult = "User can donate from emergency alert successfully.")
    public void tc_POS_4606_DonateFromAlertDetailPage(@Optional("donatedetails") String donateInfo) throws InterruptedException, AWTException, IOException {

        new RCKenya_HomePage(driver)
                .navigateToHomeURL()
                .assertNewButton()
                .clickEmergencyTile();

        new RCKenya_EmergencyAlert_ListViewPage(driver)
                .clickSearchIconFromList()
                .searchByName()
                .clickAlertNameFromList();

        new RCKenya_EmergencyAlert_DetailViewPage(driver)
                .clickDonateButtonFromDetailPage();

        new RCKenya_Donate(driver, donateInfo)
                .assertDonatePageForEmergencyAlert()
                .hoverQuestionMark()
                .assertToolTipText()
                .enterDonationAmount()
                .assertPaymentMethodField()
                .selectPaymentMethod()
                .assertCardNumberField()
                .enterCardInfo()
                .assertProceedButton()
                .clickProceedButton();
    }

    @Test
    @TestInfo(tcName = "Edit Emergency alert window", feature = "Emergency alert", expectedResult = "User can cancel edit emergency alert successfully.")
    public void tc_POS_4607_EditAlertFromDetailPage() throws InterruptedException, AWTException, IOException {

        new RCKenya_HomePage(driver)
                .navigateToHomeURL()
                .assertNewButton()
                .clickEmergencyTile();

        new RCKenya_EmergencyAlert_ListViewPage(driver)
                .clickSearchIconFromList()
                .searchByName()
                .clickAlertNameFromList();

        new RCKenya_EmergencyAlert_DetailViewPage(driver)
                .clickEditFromDetailPage()
                .editEmergencyAlertInfoFromDetailPage()
                .assertEditedInfoFromDetailPage();
    }
}
