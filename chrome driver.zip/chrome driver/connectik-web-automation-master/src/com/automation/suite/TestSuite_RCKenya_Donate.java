package com.automation.suite;

import java.awt.AWTException;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.automation.pageModel.SitePageModel;
import com.automation.suite.TestInfo;
import com.automation.testClasses.RCKenya_Donate;
import com.automation.testClasses.RCKenya_DonateConfirm;
import com.automation.testClasses.RCKenya_EnterPhoneNumber;
import com.automation.testClasses.RCKenya_HomePage;
import com.automation.testClasses.RCKenya_MembershipPage;
import com.automation.testClasses.RCKenya_PhoneCode;
import com.automation.testClasses.RCKenya_PhoneNumberConfirm;
import com.automation.testClasses.RCKenya_SiteLaunch;
import com.automation.testClasses.RCKenya_VoiceCallCode;

public class TestSuite_RCKenya_Donate extends TestHelper {

    @Parameters({"donateInfo"})
    @Test
    @TestInfo(tcName = "Donate", feature = "Donate", expectedResult = "Check ability to Donate by credit card")
    public void tc_POS_4641_CheckAbilityToDonate(@Optional("donatedetails") String donateInfo) throws InterruptedException, AWTException {

        new RCKenya_HomePage(driver)
                .assertHomePage()
                .clickDonate();
        new RCKenya_Donate(driver, donateInfo)
                .assertDonatePage()
                .hoverQuestionMark()
                .assertToolTipText();

    }

    @Parameters({"donateInfo"})
    @Test
    @TestInfo(tcName = "Donate", feature = "Donate", expectedResult = "Check ability to Donate from detail view of alert")
    public void tc_POS_4606_CheckAbilityToDonate(@Optional("donatedetails") String donateInfo) throws InterruptedException, AWTException {

        new RCKenya_HomePage(driver)
                .assertHomePage()
                .clickDonate();
        new RCKenya_Donate(driver, donateInfo)
                .assertDonatePage()
                .hoverQuestionMark()
                .assertToolTipText()
                .enterDonationAmount()
                .assertPaymentMethodField()
                .selectPaymentMethod()
                .assertCardNumberField()
                .enterCardInfo()
                .assertProceedButton()
                .clickProceedButton();

        new RCKenya_DonateConfirm(driver, donateInfo)
                .assertDonateConfirm()
                .clickConfirmButton()
                .assertPaymentComplete();

        SitePageModel.waitFor(2);

    }

}
