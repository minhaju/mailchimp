package com.automation.testClasses;

import com.automation.pageModel.SitePageModel;
import com.automation.util.AppConstant;
import com.automation.util.GiveBloodSettings;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class RCKenya_CreateBloodPage {
    public static WebDriver driver;
    GiveBloodSettings createTestDataGiveBlood;

    String giveBloodInfo;
    String strTitle;

    String strDescription;
    // String cardType;
    String strCoverPhoto;
    String strAttachment;
    String strLinks;
    String strLocation;

    public RCKenya_CreateBloodPage(WebDriver driver, String giveBloodInfo) {
        RCKenya_CreateBloodPage.driver = driver;

        PageFactory.initElements(driver, this);
        this.giveBloodInfo = giveBloodInfo;
        createTestDataGiveBlood = new GiveBloodSettings(giveBloodInfo);
        // this.giveBloodInfo=giveBloodInfo;
        strTitle = createTestDataGiveBlood.getTitle();
        strDescription = createTestDataGiveBlood.getDescription();
        strLinks = createTestDataGiveBlood.getLinks();
        strCoverPhoto = createTestDataGiveBlood.getCoverPhoto();
        strAttachment = createTestDataGiveBlood.getAttachment();
    }

    @FindBy(how = How.ID, using = "link-left-create-give-blood")
    private WebElement selectGiveBlood;
    @FindBy(how = How.ID, using = "field-new-give-blood-name")
    private WebElement titleGiveBlood;
    @FindBy(how = How.ID, using = "field-new-give-blood-description")
    private WebElement descriptionGiveBlood;
    @FindBy(how = How.CLASS_NAME, using = "input-upload__file")
    private WebElement coverPhotoGiveBlood;
    @FindBy(how = How.ID, using = "field-new-give-blood-attachments")
    private WebElement attachmentGiveBlood;
    // @FindBy(how = How.XPATH, using=
    // ".//*[@id='field-new-give-blood-attachments']") private WebElement
    // attachmentGiveBlood;

    @FindBy(how = How.NAME, using = "link")
    private WebElement linksTextBox;
    @FindBy(how = How.XPATH, using = "//i[@class='md md-add valid']")
    private WebElement plusLinkButton;
    // @FindBy(how = How.XPATH, using= "//i[@class='md md-add valid']") private
    // WebElement plusLinkButton;
    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-my-location ng-scope')]")
    private WebElement giveBloodLocationIcon;
    @FindBy(how = How.ID, using = "button-new-give-blood-post")
    private WebElement createGiveBloodButton;
    @FindBy(how = How.ID, using = "button-new-give-blood-cancel")
    private WebElement cancelButton;

    // @FindBy(how = How.XPATH, using=
    // "//div[@class='create-donation__receiver__tooltip__icon']") private
    // WebElement hoverQuestionIcon;

    public RCKenya_CreateBloodPage assertCreateMenuItemGiveBlood() {

        SitePageModel.waitForVisibilityByElement(driver, selectGiveBlood);

        return this;

    }

    public RCKenya_CreateBloodPage selectMenuItemGiveBlood() {

        // SitePageModel.waitForVisibilityByElement(driver, selectGiveBlood);
        selectGiveBlood.click();
        return this;

    }

    public RCKenya_CreateBloodPage assertCreateMenuItemGiveBloodPage() {

        SitePageModel.waitForVisibilityByElement(driver, titleGiveBlood);

        SitePageModel.waitForVisibilityByElement(driver, descriptionGiveBlood);
        Assert.assertFalse(createGiveBloodButton.isEnabled());
        // SitePageModel.waitForClickabilityByElement(driver,
        // coverPhotoGiveBlood);
        // SitePageModel.waitForVisibilityByElement(driver,
        // attachmentGiveBlood);
        // SitePageModel.waitForClickabilityByElement(driver, linksTextBox);

        // SitePageModel.waitForVisibilityByElement(driver, plusLinkButton);
        // SitePageModel.waitForVisibilityByElement(driver,
        // giveBloodLocationIcon);

        return this;

    }

    public RCKenya_CreateBloodPage assertGiveBloodPageAfterEnterRequiredField() {

        if (!coverPhotoGiveBlood.isEnabled()) {
            SitePageModel.waitFor(5);
        }
        Assert.assertTrue(coverPhotoGiveBlood.isEnabled());

        if (!attachmentGiveBlood.isEnabled()) {
            SitePageModel.waitFor(5);
        }

        Assert.assertTrue(attachmentGiveBlood.isEnabled());

        SitePageModel.waitForClickabilityByElement(driver, linksTextBox);

        // SitePageModel.waitForVisibilityByElement(driver,
        // giveBloodLocationIcon);

        return this;

    }

    public RCKenya_CreateBloodPage enterRequiredFieldData() {

        titleGiveBlood.sendKeys(strTitle);
        descriptionGiveBlood.sendKeys(strDescription);

        return this;

    }

    public RCKenya_CreateBloodPage enterOtherData() {

        coverPhotoGiveBlood.sendKeys(AppConstant.IMAGE_PATH + strCoverPhoto);

        attachmentGiveBlood.sendKeys(AppConstant.IMAGE_PATH + strAttachment);

        linksTextBox.sendKeys(strLinks);
        SitePageModel.waitForVisibilityByElement(driver, plusLinkButton);
        plusLinkButton.click();

        return this;

    }

    public RCKenya_GiveBloodDetailsView clickCreateButton() throws IOException {

        createGiveBloodButton.click();

        return new RCKenya_GiveBloodDetailsView(driver, giveBloodInfo);

    }

    public RCKenya_HomePage clickCancel() {

        cancelButton.click();

        return new RCKenya_HomePage(driver);

    }
}