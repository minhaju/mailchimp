package com.automation.testClasses;

import com.automation.pageModel.SitePageModel;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RCKenya_MembershipPage {
    public static WebDriver driver;

    public RCKenya_MembershipPage(WebDriver driver) {
        RCKenya_MembershipPage.driver = driver;

        PageFactory.initElements(driver, this);
    }

    @FindBy(how = How.ID, using = "link-left-menu-foryou")
    private WebElement homeIcon;
    @FindBy(how = How.ID, using = "link-left-toggle-create")
    private WebElement newButton;
    @FindBy(how = How.XPATH, using = ".//*[@id='main-nav']/div/ul/li[3]/a/span")
    private WebElement continueAsGuest;

    public RCKenya_MembershipPage assertMemberShipPage() {

        SitePageModel.waitForVisibilityByElement(driver, homeIcon);
        SitePageModel.waitForVisibilityByElement(driver, newButton);

        String expectedURL = "https://dev-members-ken.rc-app.com/membership/individual/";

        String getURL = driver.getCurrentUrl();

        Assert.assertTrue(getURL.equals(expectedURL));

        return this;

    }

    public RCKenya_MembershipPage assertNewUserMemberShipPage() {


        SitePageModel.waitForVisibilityByElement(driver, continueAsGuest);

        String expectedURL = "https://dev-members-ken.rc-app.com/registration/membership/";

        String getURL = driver.getCurrentUrl();

        Assert.assertTrue(getURL.equals(expectedURL));

        return this;

    }

    public RCKenya_HomePage clickContinueAsGuestLink() {

        continueAsGuest.click();

        return new RCKenya_HomePage(driver);
    }

}
