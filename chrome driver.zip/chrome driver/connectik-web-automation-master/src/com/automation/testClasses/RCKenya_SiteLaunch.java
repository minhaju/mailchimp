package com.automation.testClasses;

import com.automation.pageModel.SitePageModel;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RCKenya_SiteLaunch {
    public static WebDriver driver;

    public RCKenya_SiteLaunch(WebDriver driver) {
        RCKenya_SiteLaunch.driver = driver;

        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//span[@class='md md-close']")
    private WebElement plantTreePopUp;
    @FindBy(how = How.XPATH, using = "//button[@type='submit']")
    private WebElement loginBtn;
    @FindBy(how = How.ID, using = "select-country-code")
    private WebElement countryCode;
    @FindBy(how = How.ID, using = "field-phone")
    private WebElement mobileNumber;

    public RCKenya_SiteLaunch treePopUpClose() {

        plantTreePopUp.click();

        return this;
    }

    public RCKenya_SiteLaunch assertTreePOPup() {

        SitePageModel.waitForVisibilityByElement(driver, plantTreePopUp);

        return this;
    }

    public RCKenya_SiteLaunch checkUnauthorized() {

        SitePageModel.waitFor(2);
        driver.navigate().to("https://dev-members-ken.rc-app.com/profile/");
        return this;
    }

    public RCKenya_SiteLaunch navigateToHomePage() {

        SitePageModel.navigateToSpecificPage(driver, "https://dev-members-ken.rc-app.com");
        return this;
    }
}