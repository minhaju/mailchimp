package com.automation.testClasses;

import com.automation.pageModel.SitePageModel;
import com.automation.util.LoginSettings;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.awt.*;

public class RCKenya_EnterPhoneNumber {

    public static WebDriver driver;
    LoginSettings testDataLogin;

    String strCountryCode;
    String strPhoneNumber;
    String strFullPhoneNumber;
    private String userType;

    protected static String strRndPhoneNumber = SitePageModel.randomPhoneNumber(driver);

    public RCKenya_EnterPhoneNumber(WebDriver driver, String userType) {

        RCKenya_EnterPhoneNumber.driver = driver;

        PageFactory.initElements(driver, this);
        testDataLogin = new LoginSettings(userType);
        this.userType = userType;
        strCountryCode = testDataLogin.getCountryCode();
        strPhoneNumber = testDataLogin.getPhoneNumber();
        strFullPhoneNumber = testDataLogin.getFullPhoneNumber();
    }

    @FindBy(how = How.ID, using = "select-country-code")
    private WebElement countryCode;
    @FindBy(how = How.TAG_NAME, using = "option")
    private WebElement option;
    @FindBy(how = How.ID, using = "field-phone")
    private WebElement mobileNumber;
    @FindBy(how = How.XPATH, using = "//button[@type='submit']")
    private WebElement loginBtn;


    public RCKenya_EnterPhoneNumber selectCountry() {

        SitePageModel.selectOptionsVal(driver, countryCode, strCountryCode);
        return this;
    }

    public RCKenya_EnterPhoneNumber assertLoginButtonIsDisabled() {
        Assert.assertFalse(loginBtn.isEnabled());
        return this;
    }


    public RCKenya_EnterPhoneNumber assertPhoneNumberFieldActive() {

        SitePageModel.waitForVisibilityByElement(driver, mobileNumber);
        SitePageModel.waitForClickabilityByElement(driver, mobileNumber);
        return this;
    }

    public RCKenya_EnterPhoneNumber enterFullPhoneNumber() {

        mobileNumber.clear();
        mobileNumber.sendKeys(strFullPhoneNumber);

        return this;
    }

    public RCKenya_EnterPhoneNumber assertPhoneNumberPage() {

        SitePageModel.waitForVisibilityByElement(driver, countryCode);
        SitePageModel.waitForVisibilityByElement(driver, mobileNumber);
        SitePageModel.waitForVisibilityByElement(driver, loginBtn);
        return this;
    }

    public RCKenya_EnterPhoneNumber enterPhoneNumber() {

        mobileNumber.clear();
        mobileNumber.sendKeys(strPhoneNumber);

        return this;
    }

    public RCKenya_EnterPhoneNumber assertLoginButtonActive() {

        SitePageModel.waitForClickabilityByElement(driver, loginBtn);

        return this;
    }

    public RCKenya_PhoneNumberConfirm submitPhoneInfo() {

        loginBtn.click();

        return new RCKenya_PhoneNumberConfirm(driver, userType);
    }

    public RCKenya_EnterPhoneNumber assertSelectCountry() {

        Assert.assertTrue(countryCode.getText().contains(strCountryCode));

        return this;
    }

    public RCKenya_PhoneNumberConfirm submitLoginInfoByClick() {

        loginBtn.click();

        return new RCKenya_PhoneNumberConfirm(driver, userType);

    }

    public RCKenya_PhoneNumberConfirm submitLoginInfoByEnter()
            throws AWTException {

        SitePageModel.clickButtonByEnterKey(driver, By.xpath("//button[@type='submit']"));

        return new RCKenya_PhoneNumberConfirm(driver, userType);
    }

    public RCKenya_EnterPhoneNumber enterRandomCorrectPhoneNumber() {

        mobileNumber.sendKeys(strRndPhoneNumber);

        return this;
    }


}
