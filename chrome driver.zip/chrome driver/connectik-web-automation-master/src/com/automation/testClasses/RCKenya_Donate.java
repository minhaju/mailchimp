package com.automation.testClasses;

import com.automation.pageModel.SitePageModel;
import com.automation.util.DonateSettings;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


public class RCKenya_Donate {
    public static WebDriver driver;
    DonateSettings testDataDonate;
    String strDonationAmount;
    String strPaymentMethod;
    String strCardType;
    String strCardNumber;
    String strCardExpiryMonth;
    String strCardExpiryYear;
    String strCVV;

    String donateInfo;

    public RCKenya_Donate(WebDriver driver, String donateInfo) {
        RCKenya_Donate.driver = driver;

        PageFactory.initElements(driver, this);
        this.donateInfo = donateInfo;
        testDataDonate = new DonateSettings(donateInfo);
        strDonationAmount = testDataDonate.getDonationAmount();
        strPaymentMethod = testDataDonate.getPaymentMethod();
        //strCardType=testDataDonate.getCardType();
        strCardNumber = testDataDonate.getCardNumber();
        strCardExpiryMonth = testDataDonate.getCardExpiryMonth();
        strCardExpiryYear = testDataDonate.getCardExpiryYear();
        strCVV = testDataDonate.getCVV();

    }

    @FindBy(how = How.ID, using = "field-donation-amount")
    private WebElement donationAmount;
    @FindBy(how = How.XPATH, using = "//div[@class='create-donation__receiver__tooltip__icon']")
    private WebElement hoverQuestionIcon;
    @FindBy(how = How.XPATH, using = "//div[@class='tooltip-info__content ng-scope']/h3")
    private WebElement toolTip;
    @FindBy(how = How.ID, using = "select-donation-payment")
    private WebElement paymentMethod;
    //@FindBy(how = How.XPATH, using= "//button[(@class = 'btn btn-primary btn-wide') and text()[contains(., 'Proceed')]]") private List<WebElement>  proceedButton;
    @FindBy(how = How.XPATH, using = "//button[(@class = 'btn btn-primary btn-wide') and text()[contains(., 'Proceed')]]")
    private WebElement proceedButton;

    @FindBy(how = How.ID, using = "button-proceed")
    private WebElement proceedButtonEnable;
    @FindBy(how = How.ID, using = "select-donation-payment")
    private WebElement selectPaymentMethod;


    @FindBy(how = How.XPATH, using = "//div[@class='create-donation__receiver__text ng-scope']/small")
    private WebElement donateText;
    @FindBy(how = How.XPATH, using = "//div[@class='create-donation__receiver__text ng-scope']/h2")
    private WebElement krcsText;

    @FindBy(how = How.XPATH, using = "//div[@class='form-alert__messages']/p[1]")
    private WebElement formAlertdonationAmount;

    @FindBy(how = How.XPATH, using = "//div[@class='form-alert__messages']/p[2]")
    private WebElement formAlertpaymentMethod;
    @FindBy(how = How.XPATH, using = "//div[@class='payment-note ng-scope']")
    private WebElement footerNote;
    @FindBy(how = How.ID, using = "braintree-hosted-field-number")
    private WebElement iFrameFieldNumber;

    @FindBy(how = How.ID, using = "credit-card-number")
    private WebElement creditCardNumber;

    @FindBy(how = How.ID, using = "braintree-hosted-field-expirationMonth")
    private WebElement iFrameExpirationMonth;

    @FindBy(how = How.ID, using = "expiration-month")
    private WebElement expirationMonth;

    @FindBy(how = How.ID, using = "braintree-hosted-field-expirationYear")
    private WebElement iFrameExpirationYear;

    @FindBy(how = How.ID, using = "expiration-year")
    private WebElement expirationYear;
    @FindBy(how = How.ID, using = "braintree-hosted-field-cvv")
    private WebElement iFrameCVV;

    @FindBy(how = How.ID, using = "cvv")
    private WebElement cvv;


    public RCKenya_Donate assertDonatePage() {

        //SitePageModel.waitFor(3);
        String expectedFooterNote = "By donating, you agree by Red Cross" + '\n' + "Terms of Service and Privacy Policy";


        SitePageModel.waitForVisibilityByElement(driver, donationAmount);
        SitePageModel.waitForVisibilityByElement(driver, hoverQuestionIcon);
        SitePageModel.waitForVisibilityByElement(driver, paymentMethod);
        SitePageModel.waitForVisibilityByElement(driver, proceedButton);
        Assert.assertFalse(paymentMethod.isEnabled());
        Assert.assertFalse(proceedButton.isEnabled());

        Assert.assertTrue(donateText.getText().equals("Donate to"));
        Assert.assertTrue(krcsText.getText().equals("Kenya Red Cross Society"));
        Assert.assertTrue(formAlertdonationAmount.getText().equals("- You have to set a donation amount"));
        Assert.assertTrue(formAlertpaymentMethod.getText().equals("- You have to select a payment method"));
        Assert.assertTrue(footerNote.getText().equals(expectedFooterNote));

        SitePageModel.waitFor(4);

        return this;

    }

    public RCKenya_Donate assertDonatePageForEmergencyAlert() {

        //SitePageModel.waitFor(3);
        String expectedFooterNote = "By donating, you agree by Red Cross" + '\n' + "Terms of Service and Privacy Policy";


        SitePageModel.waitForVisibilityByElement(driver, donationAmount);
        SitePageModel.waitForVisibilityByElement(driver, hoverQuestionIcon);
        SitePageModel.waitForVisibilityByElement(driver, paymentMethod);
        SitePageModel.waitForVisibilityByElement(driver, proceedButton);
        Assert.assertFalse(paymentMethod.isEnabled());
        Assert.assertFalse(proceedButton.isEnabled());

        Assert.assertTrue(donateText.getText().equals("Donate to"));
        Assert.assertTrue(krcsText.getText().equals("Gokul Bogra"));
        Assert.assertTrue(formAlertdonationAmount.getText().equals("- You have to set a donation amount"));
        Assert.assertTrue(formAlertpaymentMethod.getText().equals("- You have to select a payment method"));
        Assert.assertTrue(footerNote.getText().equals(expectedFooterNote));


        return this;

    }

    public RCKenya_Donate assertToolTipText() {
        String expectedToolTipTitle = "Make a difference be the difference";
        SitePageModel.waitForVisibilityByElement(driver, toolTip);
        Assert.assertTrue(toolTip.getText().equals(expectedToolTipTitle));

        return this;

    }

    public RCKenya_Donate hoverQuestionMark() {

        Actions action = new Actions(driver);

        action.moveToElement(hoverQuestionIcon).build().perform();

        return this;

    }

    public RCKenya_Donate enterDonationAmount() {

        donationAmount.sendKeys(strDonationAmount);
        //SitePageModel.waitFor(2);
        return this;

    }

    public RCKenya_Donate selectPaymentMethod() {

        SitePageModel.selectOptionsVal(driver, selectPaymentMethod, strPaymentMethod);
        SitePageModel.waitFor(2);

        return this;
    }

    public RCKenya_Donate assertPaymentMethodField() {

        SitePageModel.waitForVisibilityByElement(driver, paymentMethod);
        SitePageModel.waitForVisibilityByElement(driver, proceedButton);
        Assert.assertTrue(paymentMethod.isEnabled());
        Assert.assertFalse(proceedButton.isEnabled());

        return this;
    }

    public RCKenya_Donate assertCardNumberField() {

        SitePageModel.waitForVisibilityByElement(driver, iFrameFieldNumber);
        driver.switchTo().frame(iFrameFieldNumber);
        SitePageModel.waitForVisibilityByElement(driver, creditCardNumber);
        driver.switchTo().defaultContent();

        SitePageModel.waitForVisibilityByElement(driver, iFrameExpirationMonth);
        driver.switchTo().frame(iFrameExpirationMonth);
        SitePageModel.waitForVisibilityByElement(driver, expirationMonth);
        driver.switchTo().defaultContent();

        SitePageModel.waitForVisibilityByElement(driver, iFrameExpirationYear);
        driver.switchTo().frame(iFrameExpirationYear);
        SitePageModel.waitForVisibilityByElement(driver, expirationYear);
        driver.switchTo().defaultContent();

        SitePageModel.waitForVisibilityByElement(driver, iFrameCVV);
        driver.switchTo().frame(iFrameCVV);
        SitePageModel.waitForVisibilityByElement(driver, cvv);
        driver.switchTo().defaultContent();

        SitePageModel.waitForVisibilityByElement(driver, proceedButton);
        Assert.assertFalse(proceedButton.isEnabled());

        return this;
    }

    public RCKenya_Donate enterCardInfo() {

        driver.switchTo().frame(iFrameFieldNumber);
        creditCardNumber.sendKeys(strCardNumber);
        driver.switchTo().defaultContent();

        driver.switchTo().frame(iFrameExpirationMonth);
        expirationMonth.sendKeys(strCardExpiryMonth);
        driver.switchTo().defaultContent();

        driver.switchTo().frame(iFrameExpirationYear);
        expirationYear.sendKeys(strCardExpiryYear);
        driver.switchTo().defaultContent();

        driver.switchTo().frame(iFrameCVV);
        cvv.sendKeys(strCVV);
        driver.switchTo().defaultContent();

        return this;
    }

    public RCKenya_Donate assertProceedButton() {

        SitePageModel.waitForVisibilityByElement(driver, proceedButtonEnable);
        // Assert.assertTrue(proceedButtonEnable.isEnabled());

        return this;
    }

    public RCKenya_DonateConfirm clickProceedButton() {
        SitePageModel.waitFor(8);
        proceedButtonEnable.click();

        SitePageModel.waitFor(22);
        return new RCKenya_DonateConfirm(driver, donateInfo);
    }

}
