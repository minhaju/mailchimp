/**
 * Created by moshiur on 05/10/16.
 */

package com.automation.testClasses;


import com.automation.pageModel.SitePageModel;
import com.automation.util.AppConstant;
import com.automation.util.EmergencyAlertSettings;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.FileNotFoundException;
import java.io.IOException;


public class RCKenya_EmergencyAlert_CreatePage {

    public static WebDriver driver;
    EmergencyAlertSettings testDataEmergencyAlert;

    String emergencyAlertName;
    String emergencyAlertDescription;
    String emergencyAlertLink;
    String currentLocation;
    String searchKeyWordName;
    String searchKeyWordDescription;
    String editedEmergencyAlertName;
    String editedEmergencyAlertDescription;


    protected static String strEmergencyAlertRandomNumber = SitePageModel.randomPhoneCode(driver);

    public RCKenya_EmergencyAlert_CreatePage(WebDriver driver) throws FileNotFoundException, IOException {

        RCKenya_EmergencyAlert_CreatePage.driver = driver;

        PageFactory.initElements(driver, this);

        testDataEmergencyAlert = new EmergencyAlertSettings();

        emergencyAlertName = testDataEmergencyAlert.getEmergencyAlertName();
        emergencyAlertDescription = testDataEmergencyAlert.getEmergencyAlertDescription();
        emergencyAlertLink = testDataEmergencyAlert.getEmergencyAlertURL();
        currentLocation = testDataEmergencyAlert.getCurrentLocation();
        searchKeyWordName = testDataEmergencyAlert.getSearchKeyWordName();
        searchKeyWordDescription = testDataEmergencyAlert.getSearchKeyWordDescription();
        editedEmergencyAlertName = testDataEmergencyAlert.getEditedEmergencyAlertName();
        editedEmergencyAlertDescription = testDataEmergencyAlert.getEditedEmergencyAlertDescription();
    }


    @FindBy(how = How.ID, using = "link-home-emergencies")
    private WebElement emergencyTile;
    @FindBy(how = How.ID, using = "link-left-toggle-create")
    private WebElement newButton;
    @FindBy(how = How.XPATH, using = "//a[contains(@ng-click, 'createEmergency') and text()='Emergency Alert']")
    private WebElement emergencyAlertCreationIcon;
    @FindBy(how = How.ID, using = "button-new-emergency-cancel")
    private WebElement emergencyAlertFormCancel;
    @FindBy(how = How.ID, using = "field-new-emergency-name")
    private WebElement emergencyAlertNameField;
    @FindBy(how = How.ID, using = "field-new-emergency-description")
    private WebElement emergencyAlertDescriptionField;
    @FindBy(how = How.ID, using = "field-new-emergency-attachments")
    private WebElement emergencyAlertattachmentField;
    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-my-location ng-scope')]")
    private WebElement emergencyAlertLocationIcon;
    @FindBy(how = How.ID, using = "field-new-emergency-location")
    private WebElement emergencyAlertLocationField;
    @FindBy(how = How.ID, using = "button-new-emergency-post")
    private WebElement postButton;
    @FindBy(how = How.XPATH, using = "//input[contains(@class, 'form-control ng-pristine ng-untouched ng-valid ng-valid-url')]")
    private WebElement emergencyAlertLinkField;
    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-add valid')]")
    private WebElement emergencyAlertLinkConfirmPlus;
    @FindBy(how = How.XPATH, using = "//label[contains(@class, 'control-label') and text()='Featured Story']")
    private WebElement featuredCheckbox;
    @FindBy(how = How.XPATH, using = "//a[contains(@class, 'btn btn-success btn_event btn-wide btn-lg ng-scope') and text()=' Donate']")
    private WebElement donateButton;
    @FindBy(how = How.XPATH, using = "//post-date[contains(@class, 'ng-isolate-scope') and text()='now']")
    private WebElement creationTime;
    @FindBy(how = How.XPATH, using = "//div[contains(@class,'post-entities-ctrl__title__name ng-binding')]")
    private WebElement alertNameFromDetailPage;
    @FindBy(how = How.XPATH, using = "//p[contains(@class,'ng-binding')]")
    private WebElement alertDescriptionFromDetailPage;
    @FindBy(how = How.XPATH, using = "//a[contains(@class,'ng-binding')]")
    private WebElement alertURLFromDetailPage;
    @FindBy(how = How.XPATH, using = "//div[@class='tooltip-info tooltip-info_left ng-scope']")
    private WebElement hoverQuestionIcon;
    @FindBy(how = How.XPATH, using = "//div[@class='tooltip-info__description']/p")
    private WebElement tooltip;
    @FindBy(how = How.ID, using = "button-new-emergency-edit")
    private WebElement editButton;
    @FindBy(how = How.XPATH, using = "//a[contains(@class, 'btn btn-primary btn-wide btn-lg btn-stroke post-entities-ctrl__edit pull-right ng-scope')]")
    private WebElement editButtonFromDetialPage;


    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-mode-edit')]")
    private WebElement editButtonFromList;

    @FindBy(how = How.ID, using = "button-new-emergency-delete")
    private WebElement deleteButton;
    @FindBy(how = How.XPATH, using = "//button[(@class = 'btn btn-primary btn-wide btn-secondary') and text()='Cancel']")
    private WebElement cancelConfirm;
    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-close close')]")
    private WebElement searchCrossIcon;
    @FindBy(how = How.XPATH, using = "//button[(@class = 'btn btn-primary btn-wide') and text()='Delete']")
    private WebElement deleteConfirm;
    @FindBy(how = How.XPATH, using = "//div[@class = 'modal__success']/h4")
    private WebElement deleteConfirmText;
    @FindBy(how = How.XPATH, using = "//span[(@class = 'one-word ng-binding')]")
    private WebElement alertCreatorName;
    @FindBy(how = How.XPATH, using = "//img[(@class = 'ng-scope img-circle')]")
    private WebElement alertCreatorAvatarIcon;
    @FindBy(how = How.XPATH, using = "//div[(@class = 'staticGoogleMap__navigate ng-scope')]")
    private WebElement alertNavigateButton;





    public RCKenya_EmergencyAlert_CreatePage assertHelpToolTip() {

        SitePageModel.waitFor(5);
        Actions action = new Actions(driver);

        action.moveToElement(hoverQuestionIcon).build().perform();

        tooltip.getText();

        return this;
    }

    public RCKenya_EmergencyAlert_CreatePage fillEmergencyAlertValue() {

        SitePageModel.waitForVisibilityByElement(driver, emergencyAlertNameField);

        emergencyAlertNameField.clear();
        emergencyAlertNameField.sendKeys(emergencyAlertName);

        emergencyAlertDescriptionField.clear();
        emergencyAlertDescriptionField.sendKeys(emergencyAlertDescription);
        System.out.println(emergencyAlertDescription);

        String strUploadImage = AppConstant.IMAGE_PATH + "testimg1.png";
        emergencyAlertattachmentField.sendKeys(strUploadImage);
        SitePageModel.waitFor(3);

        emergencyAlertLinkField.clear();
        emergencyAlertLinkField.sendKeys(emergencyAlertLink);
//		SitePageModel.waitFor(2);
        SitePageModel.waitForClickabilityByElement(driver, emergencyAlertLinkConfirmPlus);
        emergencyAlertLinkConfirmPlus.click();

//		SitePageModel.waitFor(2);
        emergencyAlertLocationField.clear();
//        emergencyAlertLocationField.sendKeys(currentLocation);
//        emergencyAlertLocationField.sendKeys(Keys.TAB);
//        emergencyAlertLocationField.sendKeys(Keys.TAB);
//		SitePageModel.waitFor(5);
        SitePageModel.waitForVisibilityByElement(driver, featuredCheckbox);

        featuredCheckbox.click();

        return this;
    }

    public RCKenya_EmergencyAlert_CreatePage assertEmergencyAlertPostButtonActive() {

        SitePageModel.waitForVisibilityByElement(driver, postButton);
        SitePageModel.waitForClickabilityByElement(driver, postButton);
        return this;
    }

    public RCKenya_EmergencyAlert_CreatePage assertEmergencyAlertEditButtonActive() {

        SitePageModel.waitForVisibilityByElement(driver, editButton);
        SitePageModel.waitForClickabilityByElement(driver, editButton);
        return this;
    }

    public RCKenya_EmergencyAlert_CreatePage cancelEmergencyCreationForm() {

        SitePageModel.waitForVisibilityByElement(driver, emergencyAlertFormCancel);
        SitePageModel.waitForClickabilityByElement(driver, emergencyAlertFormCancel);
        emergencyAlertFormCancel.click();
        return this;
    }

    public RCKenya_EmergencyAlert_CreatePage assertEmergencyEditCancel() {

        String receivedName = alertNameFromDetailPage.getText();
        Assert.assertEquals(receivedName, emergencyAlertName);

        String receivedDescription = alertDescriptionFromDetailPage.getText();
        Assert.assertEquals(emergencyAlertDescription, receivedDescription);

        return this;
    }

    public RCKenya_EmergencyAlert_CreatePage assertEmergencyAlertNotEdited() {

        alertURLFromDetailPage.getText();

        SitePageModel.waitForVisibilityByElement(driver, donateButton);
        SitePageModel.waitForClickabilityByElement(driver, newButton);

        return this;
    }

    public RCKenya_EmergencyAlert_CreatePage assertEmergencyAlertNotCreated() {

        SitePageModel.waitForVisibilityByElement(driver, emergencyTile);
        SitePageModel.waitForVisibilityByElement(driver, newButton);

        return this;
    }

    public RCKenya_EmergencyAlert_CreatePage createEmergencyAlert() {

        SitePageModel.waitForVisibilityByElement(driver, postButton);
        SitePageModel.waitForClickabilityByElement(driver, postButton);

        postButton.click();

        return this;
    }

    public RCKenya_EmergencyAlert_CreatePage assertEmergencyAlertDetailPage() {

        SitePageModel.waitForVisibilityByElement(driver, donateButton);

        Assert.assertEquals(emergencyAlertName, alertNameFromDetailPage.getText());
        Assert.assertEquals(emergencyAlertDescription, alertDescriptionFromDetailPage.getText());
        Assert.assertEquals(emergencyAlertLink, alertURLFromDetailPage.getText());

        return this;
    }

    public RCKenya_EmergencyAlert_CreatePage editEmergencyAlertInfoFromList() {

        emergencyAlertNameField.clear();
        emergencyAlertNameField.sendKeys(editedEmergencyAlertName);
        emergencyAlertDescriptionField.clear();
        emergencyAlertDescriptionField.sendKeys(editedEmergencyAlertDescription);

        editButton.click();
        SitePageModel.waitFor(2);
        return this;
    }

    public RCKenya_EmergencyAlert_CreatePage editEmergencyAlertInfoFromDetailPage() {

        emergencyAlertNameField.clear();
        emergencyAlertNameField.sendKeys(emergencyAlertName);
        emergencyAlertDescriptionField.clear();
        emergencyAlertDescriptionField.sendKeys(emergencyAlertDescription);

        editButton.click();
        SitePageModel.waitFor(2);
        return this;
    }


    public RCKenya_EmergencyAlert_CreatePage assertEditedInfoFromListPage() {

        SitePageModel.waitForVisibilityByElement(driver, alertNameFromDetailPage);
        SitePageModel.waitForVisibilityByElement(driver, alertDescriptionFromDetailPage);

        Assert.assertEquals(editedEmergencyAlertName, alertNameFromDetailPage.getText());
        Assert.assertEquals(editedEmergencyAlertDescription, alertDescriptionFromDetailPage.getText());

        return this;
    }




    public RCKenya_EmergencyAlert_CreatePage clickDeleteButton() {

        deleteButton.click();
        return this;

    }

    public RCKenya_EmergencyAlert_CreatePage assertDeleteConfirm() {

        SitePageModel.waitForVisibilityByElement(driver, deleteConfirmText);

        SitePageModel.waitForClickabilityByElement(driver, deleteConfirm);
        deleteConfirm.click();

        return this;
    }

    public RCKenya_EmergencyAlert_CreatePage cancelDeleteConfirm() {

        SitePageModel.waitForVisibilityByElement(driver, cancelConfirm);
        SitePageModel.waitForClickabilityByElement(driver, cancelConfirm);
        cancelConfirm.click();
        SitePageModel.waitForVisibilityByElement(driver, donateButton);
        SitePageModel.waitForVisibilityByElement(driver, editButtonFromDetialPage);
        return this;
    }

}
