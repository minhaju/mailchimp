/**
 * Created by moshiur on 05/10/16.
 */

package com.automation.testClasses;


import com.automation.pageModel.SitePageModel;
import com.automation.util.EmergencyAlertSettings;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;


public class RCKenya_EmergencyAlert_ListViewPage {

    public static WebDriver driver;
    EmergencyAlertSettings testDataEmergencyAlert;

    String emergencyAlertName;
    String emergencyAlertDescription;
    String emergencyAlertLink;
    String currentLocation;
    String searchKeyWordName;
    String searchKeyWordDescription;
    String editedEmergencyAlertName;
    String editedEmergencyAlertDescription;
    String donateInfo;

    protected static String strEmergencyAlertRandomNumber = SitePageModel.randomPhoneCode(driver);

    public RCKenya_EmergencyAlert_ListViewPage(WebDriver driver) {

        RCKenya_EmergencyAlert_ListViewPage.driver = driver;

        PageFactory.initElements(driver, this);

        testDataEmergencyAlert = new EmergencyAlertSettings();

        emergencyAlertName = testDataEmergencyAlert.getEmergencyAlertName();
        emergencyAlertDescription = testDataEmergencyAlert.getEmergencyAlertDescription();
        emergencyAlertLink = testDataEmergencyAlert.getEmergencyAlertURL();
        currentLocation = testDataEmergencyAlert.getCurrentLocation();
        searchKeyWordName = testDataEmergencyAlert.getSearchKeyWordName();
        searchKeyWordDescription = testDataEmergencyAlert.getSearchKeyWordDescription();
        editedEmergencyAlertName = testDataEmergencyAlert.getEditedEmergencyAlertName();
        editedEmergencyAlertDescription = testDataEmergencyAlert.getEditedEmergencyAlertDescription();
    }

//     String searchKeyWordName2 = "ROOTNEXTalert";
//     String searchKeyWordDescription2 = "RNDescription";

//     String emergencyAlertName = "Test emergency alert "+ strEmergencyAlertName;
//     String emergencyAlertDescription = "Test emergency alert description 4600";
//     String emergencyAlertLink = "https://www.test.com";
//     String currentLocation = "Rd 12, Dhaka, Bangladesh";

//     String editedEmergencyAlertName = "ROOTNEXTalertEdited "+ emergencyAlertName;
//     String editedEmergencyAlertDescription = "RNDescriptionEdited "+ emergencyAlertName;


    @FindBy(how = How.ID, using = "field-new-emergency-name")
    private WebElement emergencyAlertNameField;
    @FindBy(how = How.ID, using = "field-new-emergency-description")
    private WebElement emergencyAlertDescriptionField;
    @FindBy(how = How.XPATH, using = "//a[contains(@class, 'btn btn-success btn_event btn-wide btn-lg ng-scope') and text()=' Donate']")
    private WebElement donateButton;
    @FindBy(how = How.XPATH, using = "//div[contains(@class,'post-entities-ctrl__title__name ng-binding')]")
    private WebElement alertNameFromDetailPage;
    @FindBy(how = How.XPATH, using = "//p[contains(@class,'ng-binding')]")
    private WebElement alertDescriptionFromDetailPage;
    @FindBy(how = How.ID, using = "button-new-emergency-edit")
    private WebElement editButton;
    @FindBy(how = How.XPATH, using = "//a[contains(@class, 'btn btn-primary btn-wide btn-lg btn-stroke post-entities-ctrl__edit pull-right ng-scope')]")
    private WebElement editButtonFromDetialPage;
    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-search search')]")
    private WebElement searchIcon;
    @FindBy(how = How.XPATH, using = "//span[contains(@class, 'post__actions__text') and text()='Donate']")
    private WebElement donateIcon;
    @FindBy(how = How.XPATH, using = "//div[contains(@class, 'sidebar-menu-subheader') and text()='Type']")
    private WebElement typeFilter;
    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-view-list')]")
    private WebElement listIcon;
    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-explore')]")
    private WebElement mapIcon;
    @FindBy(how = How.XPATH, using = "//h4[contains(@class, 'ng-binding ng-scope')]")
    private WebElement alertNameFromList;
    @FindBy(how = How.XPATH, using = "//div[contains(@class, 'post__date ng-binding ng-scope')]")
    private WebElement alertTime;
    @FindBy(how = How.XPATH, using = "//div[contains(@class, 'post__body__content__description ng-scope')]")
    private WebElement alertDescriptionFromList;
    @FindBy(how = How.XPATH, using = "//span[contains(@class, 'ng-binding ng-scope')]")
    private WebElement alertDistance;
    @FindBy(how = How.XPATH, using = "//div[contains(@class, 'post__image__placeholder ng-scope')]")
    private WebElement alertImage;
    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-mode-edit')]")
    private WebElement editButtonFromList;
    @FindBy(how = How.XPATH, using = "//input[contains(@ng-model, 'searchValue')]")
    private WebElement searchField;
    @FindBy(how = How.ID, using = "button-new-emergency-delete")
    private WebElement deleteButton;
    @FindBy(how = How.XPATH, using = "//button[(@class = 'btn btn-primary btn-wide btn-secondary') and text()='Cancel']")
    private WebElement cancelConfirm;
    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-close close')]")
    private WebElement searchCrossIcon;
    @FindBy(how = How.XPATH, using = "//button[(@class = 'btn btn-primary btn-wide') and text()='Delete']")
    private WebElement deleteConfirm;
    @FindBy(how = How.XPATH, using = "//div[@class = 'modal__success']/h4")
    private WebElement deleteConfirmText;
    @FindBy(how = How.XPATH, using = "//i[(@class = 'md md-location-on')]")
    private WebElement distanceIcon;
    @FindBy(how = How.XPATH, using = "//i[(@class = 'md md-favorite')]")
    private WebElement HeartIconDonateCreationPage;
    @FindBy(how = How.XPATH, using = "//span[(@class = 'icon circle circle-products')]")
    private WebElement HeartIconDonate;
    @FindBy(how = How.XPATH, using = "//div[@class='create-donation__receiver__text ng-scope']/small")
    private WebElement donateText;


    public RCKenya_EmergencyAlert_ListViewPage clickSearchIconFromList() {

        SitePageModel.waitFor(5);
        searchIcon.click();
        SitePageModel.waitFor(5);
        SitePageModel.waitForVisibilityByElement(driver, searchField);
        SitePageModel.waitForClickabilityByElement(driver, searchField);
        return this;

    }


    public RCKenya_EmergencyAlert_ListViewPage assertEmergencyAlertListPage() {

        SitePageModel.waitForVisibilityByElement(driver, searchIcon);
        SitePageModel.waitForVisibilityByElement(driver, donateIcon);
        SitePageModel.waitForVisibilityByElement(driver, typeFilter);
        SitePageModel.waitForVisibilityByElement(driver, listIcon);
        SitePageModel.waitForVisibilityByElement(driver, mapIcon);

//        SitePageModel.scrollBottomOfPage(driver);
//        SitePageModel.checkUrl(driver,"https://dev-members-ken.rc-app.com/explore/emergencies/");
        return this;
    }

    public RCKenya_EmergencyAlert_ListViewPage assertEmergencyAlertList() {

        int totalAlertList = driver.findElements(By.xpath("//div[contains(@class,'post ng-scope')]")).size();

        if (totalAlertList > 0) {
            Assert.assertNotSame(totalAlertList, 0);
        } else {
            Assert.assertSame(totalAlertList, 0);
        }
        return this;
    }

    public RCKenya_EmergencyAlert_EditPage clickEditButtonFromList() {


        editButtonFromList.click();
        SitePageModel.waitForVisibilityByElement(driver, emergencyAlertNameField);

        return new RCKenya_EmergencyAlert_EditPage(driver);
    }

    public RCKenya_EmergencyAlert_ListViewPage assertPeculiaritiesOfList() {

        SitePageModel.waitForVisibilityByElement(driver, alertNameFromList);
        SitePageModel.waitForVisibilityByElement(driver, alertTime);
        SitePageModel.waitForVisibilityByElement(driver, alertDescriptionFromList);
        SitePageModel.waitForVisibilityByElement(driver, alertDistance);
        SitePageModel.waitForVisibilityByElement(driver, alertImage);

        return this;
    }

    public RCKenya_EmergencyAlert_ListViewPage clickSearchIcon() {

        SitePageModel.waitFor(5);
        searchIcon.click();
        SitePageModel.waitFor(5);
        SitePageModel.waitForVisibilityByElement(driver, searchField);
        SitePageModel.waitForClickabilityByElement(driver, searchField);
        return this;

    }

    public RCKenya_EmergencyAlert_ListViewPage searchByName() {

        System.out.println(searchKeyWordName);
        searchField.sendKeys(searchKeyWordName);
        SitePageModel.waitFor(1);
        SitePageModel.waitForVisibilityByElement(driver, alertNameFromList);
        return this;

    }

    public RCKenya_EmergencyAlert_ListViewPage assertSearchByName() {

        String receivedName = alertNameFromList.getText();
        Assert.assertEquals(receivedName, emergencyAlertName);

        return this;
    }

    public RCKenya_EmergencyAlert_ListViewPage ClickSearchCrossIcon() {

        SitePageModel.waitForVisibilityByElement(driver, searchCrossIcon);

        searchCrossIcon.click();
        SitePageModel.waitFor(1);

        SitePageModel.waitForVisibilityByElement(driver, alertNameFromList);

        String firstName = alertNameFromList.getText();
//		Assert.assertNotEquals(searchKeyWordName, firstName);
        Assert.assertEquals(emergencyAlertName, firstName);

        return this;
    }

    public RCKenya_EmergencyAlert_ListViewPage searchByDescription() {

        searchField.sendKeys(searchKeyWordDescription);
        SitePageModel.waitFor(1);
        SitePageModel.waitForVisibilityByElement(driver, alertNameFromList);

        String receivedName = alertDescriptionFromList.getText();
        Assert.assertEquals(receivedName, emergencyAlertDescription);

        return this;
    }

    public RCKenya_EmergencyAlert_ListViewPage assertClickMapListIcon() {

        int listInput1 = driver.findElements(By.xpath("//div[contains(@class,'post ng-scope')]")).size();

        String beforeName = alertNameFromList.getText();
        System.out.println(listInput1);

        mapIcon.click();
        SitePageModel.waitFor(5);

        listIcon.click();
        SitePageModel.waitFor(5);

        String afterName = alertNameFromList.getText();

        int listInput2 = driver.findElements(By.xpath("//div[contains(@class,'post ng-scope')]")).size();
        System.out.println(listInput2);

        Assert.assertEquals(listInput1, listInput2);
        Assert.assertEquals(beforeName, afterName);
        return this;
    }


    public RCKenya_EmergencyAlert_DetailViewPage clickAlertNameFromList() {

        SitePageModel.waitForClickabilityByElement(driver, alertNameFromList);
        alertNameFromList.click();

        SitePageModel.waitForVisibilityByElement(driver, donateButton);

        SitePageModel.waitFor(2);
        return new RCKenya_EmergencyAlert_DetailViewPage(driver);
    }


    public RCKenya_EmergencyAlert_ListViewPage editEmergencyAlertInfoFromList() {

        emergencyAlertNameField.clear();
        emergencyAlertNameField.sendKeys(editedEmergencyAlertName);
        emergencyAlertDescriptionField.clear();
        emergencyAlertDescriptionField.sendKeys(editedEmergencyAlertDescription);

        editButton.click();
        SitePageModel.waitFor(2);
        return this;
    }

    public RCKenya_EmergencyAlert_ListViewPage assertEditedInfoFromListPage() {

        SitePageModel.waitForVisibilityByElement(driver, alertNameFromDetailPage);
        SitePageModel.waitForVisibilityByElement(driver, alertDescriptionFromDetailPage);

        Assert.assertEquals(editedEmergencyAlertName, alertNameFromDetailPage.getText());
        Assert.assertEquals(editedEmergencyAlertDescription, alertDescriptionFromDetailPage.getText());

        return this;
    }


    public RCKenya_EmergencyAlert_ListViewPage clickDeleteButton() {

        deleteButton.click();
        return this;

    }

    public RCKenya_EmergencyAlert_ListViewPage assertDeleteConfirm() {

        SitePageModel.waitForVisibilityByElement(driver, deleteConfirmText);

        SitePageModel.waitForClickabilityByElement(driver, deleteConfirm);
        deleteConfirm.click();

        return this;
    }

    public RCKenya_EmergencyAlert_ListViewPage cancelDeleteConfirm() {

        SitePageModel.waitForVisibilityByElement(driver, cancelConfirm);
        SitePageModel.waitForClickabilityByElement(driver, cancelConfirm);
        cancelConfirm.click();
        SitePageModel.waitForVisibilityByElement(driver, donateButton);
        SitePageModel.waitForVisibilityByElement(driver, editButtonFromDetialPage);
        return this;
    }

    public RCKenya_Donate donateFromAlertList() {

        SitePageModel.waitForVisibilityByElement(driver, donateIcon);

        donateIcon.click();

        SitePageModel.waitForVisibilityByElement(driver, donateText);

        return new RCKenya_Donate(driver, donateInfo);
    }
}
