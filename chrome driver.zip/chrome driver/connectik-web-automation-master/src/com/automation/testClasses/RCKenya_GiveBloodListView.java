package com.automation.testClasses;

import com.automation.pageModel.SitePageModel;
import com.automation.util.AppConstant;
import com.automation.util.GiveBloodSettings;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;
import java.util.List;

//import java.util.Set;
//import com.automation.util.DonateSettings;
//import com.automation.util.LoginSettings;

public class RCKenya_GiveBloodListView {
    public static WebDriver driver;
    GiveBloodSettings testDataGiveBlood;
    RCKenya_EditBloodPage editBloodPage;

    String giveBloodInfo;
    String strTitle;

    String strDescription;
    // String cardType;
    String coverPhoto;
    String attachment;
    String links;
    String location;
    // @FindBy(how = How.ID, using= "field-donation-amount") private WebElement
    // donationAmount;


    public RCKenya_GiveBloodListView(WebDriver driver, String giveBloodInfo) {
        RCKenya_GiveBloodListView.driver = driver;

        PageFactory.initElements(driver, this);
        this.giveBloodInfo = giveBloodInfo;
        testDataGiveBlood = new GiveBloodSettings(giveBloodInfo);
        strTitle = testDataGiveBlood.getTitle();
        strDescription = testDataGiveBlood.getDescription();
        // editBloodPage= new RCKenya_EditBloodPage(driver, giveBloodInfo);

		/*
         * We use RCKenya_EditBloodPage instance as we need to check edited data
		 * shows in list
		 */

    }

    @FindBy(how = How.XPATH, using = "//li[(@class = 'sidebar-menu-header sidebar-menu-element')]/span/span[text()[contains(., 'Filters')]]")
    private WebElement filtersText;
    @FindBy(how = How.XPATH, using = "//div[@class = 'search-box ng-pristine ng-untouched ng-valid ng-isolate-scope']")
    private WebElement searchIcon;

    @FindBy(how = How.XPATH, using = ".//*[@id='infinity-scroll-1']/div[1]/a/img")
    private WebElement pledge25Banner;


    @FindBy(how = How.XPATH, using = "//div[@class = 'post__body__content']/h4")
    private WebElement postTitle;
    @FindBy(how = How.XPATH, using = "//div[@class = 'post__body__content']/div[@class='post__date ng-binding ng-scope']")
    private WebElement postDate;
    @FindBy(how = How.XPATH, using = "//div[@class = 'post__body__content__description ng-scope']/p")
    private WebElement postDescription;
    @FindBy(how = How.XPATH, using = "//div[@class = 'post__body__content']/h5/a")
    private WebElement postCreator;
    @FindBy(how = How.XPATH, using = "//a[@class = 'post__actions__icon icon circle circle-navigate ng-isolate-scope']")
    private WebElement navigateButton;
    //@FindBy(how = How.XPATH, using = "//span[(@class = 'post__actions__text') and text()='Edit']")
    // private WebElement editButton;

    @FindBy(how = How.XPATH, using = "//span[(@class = 'post__actions__text')]/span[text()='Edit']")
    private WebElement editButton;

    @FindBy(how = How.XPATH, using = "//a[@class = 'modal__success']/h4")
    private WebElement confirmationWindowText;
    @FindBy(how = How.XPATH, using = "//button[@class = 'btn btn-primary btn-wide btn-secondary")
    private WebElement CancelConfirm;
    @FindBy(how = How.XPATH, using = "//div[@class = 'post__body__content']")
    private WebElement postBodyContent;
    @FindBy(how = How.XPATH, using = "//input[contains(@ng-model, 'searchValue')]")
    private WebElement searchTextBox;
    @FindBy(how = How.XPATH, using = "//i[@class='md md-close close']")
    private WebElement searchCloseIcon;
    @FindBy(how = How.XPATH, using = ".//*[@id='infinity-scroll-1']/div[2]/h4/small")
    private WebElement nothingFoundText;
    @FindBy(how = How.XPATH, using = "//ul[(@class='nav nav-tabs')]/li[1]/a")
    private WebElement listView;
    @FindBy(how = How.XPATH, using = "//ul[(@class='nav nav-tabs')]/li[1]/a/i")
    private WebElement listViewIcon;
    @FindBy(how = How.XPATH, using = "//ul[(@class='nav nav-tabs')]/li[2]/a")
    private WebElement mapView;
    @FindBy(how = How.XPATH, using = "//ul[(@class='nav nav-tabs')]/li[2]/a/i")
    private WebElement mapViewIcon;
    @FindBy(how = How.XPATH, using = ".//*[@id='content']/div/div/div/div/div/div[2]/div[1]/google-map/ui-gmap-google-map/div/div[1]/div/div[1]/div[4]/div[4]/div/div/div[4]/div/button")
    private WebElement pinCode;
    @FindBy(how = How.XPATH, using = "//div[@class = 'post__body__content']/h4")
    private List<WebElement> listScrollElement;
    @FindBy(how = How.XPATH, using = "//div[@class='list-group-item']/h4")
    private WebElement titleMapModalWindow;
    @FindBy(how = How.XPATH, using = "//div[@class='list-group-item']/h5/a")
    private WebElement creatorMapModalWindow;
    @FindBy(how = How.XPATH, using = "//button[@class='btn btn-success btn-wide btn_event ng-scope']")
    private WebElement viewButtonMapModalWindow;
    @FindBy(how = How.XPATH, using = "//div[@class = 'post__body__content']/h4")
    private List<WebElement> listPostTitle;

    public RCKenya_GiveBloodListView assertGiveBloodListView() {

        SitePageModel.waitForVisibilityByElement(driver, searchIcon);
        SitePageModel.waitForClickabilityByElement(driver, searchIcon);

        SitePageModel.waitForVisibilityByElement(driver, filtersText);

        SitePageModel.waitForVisibilityByElement(driver, mapViewIcon);
        SitePageModel.waitForVisibilityByElement(driver, listViewIcon);


        SitePageModel.waitForVisibilityByElement(driver, postTitle);
        SitePageModel.waitForVisibilityByElement(driver, postCreator);
        SitePageModel.waitForVisibilityByElement(driver, postDate);


        SitePageModel.waitForVisibilityByElement(driver, mapView);
        SitePageModel.waitForVisibilityByElement(driver, listView);


        SitePageModel.waitForVisibilityByElement(driver, postBodyContent);


        SitePageModel.waitForVisibilityByElement(driver, navigateButton);
        SitePageModel.waitForVisibilityByElement(driver, editButton);

        //System.out.println(listPostTitle.size());


        SitePageModel.waitForVisibilityByElement(driver, pledge25Banner);
        // System.out.println(pledge25Banner.getAttribute("src"));
        Assert.assertTrue(pledge25Banner.getAttribute("src").contains("pledge_25_banner.png"));


        return this;

    }

    public RCKenya_GiveBloodListView assertCursorPosition() {


        Assert.assertTrue(driver.switchTo().activeElement().getAttribute("placeholder").equals(searchTextBox.getAttribute("placeholder")));


        return this;

    }

    public RCKenya_GiveBloodListView openMapView() {


        mapView.click();

        return this;

    }

    public RCKenya_GiveBloodListView assertMapView() {

        SitePageModel.waitFor(1);
        Assert.assertTrue(driver.getCurrentUrl().contains("https://dev-members-ken.rc-app.com/explore/give-blood/map/"));
        SitePageModel.waitForVisibilityByElement(driver, listView);
        return this;

    }

    public RCKenya_GiveBloodListView openListView() {

        listView.click();

        return this;

    }

    public RCKenya_GiveBloodListView assertMapModal() {

        SitePageModel.waitForVisibilityByElement(driver, titleMapModalWindow);
        SitePageModel.waitForVisibilityByElement(driver, creatorMapModalWindow);
        SitePageModel.waitForVisibilityByElement(driver, viewButtonMapModalWindow);


        return this;

    }

    public RCKenya_GiveBloodListView clickMapViewPin() {

        SitePageModel.waitFor(10);
        String imagePath = AppConstant.IMAGE_PATH + "gpin.jpg";
        SitePageModel.clickLocationBySikuli(imagePath);
        //viewButtonMapModalWindow.click();

        return this;

    }

    public RCKenya_GiveBloodDetailsView clickViewButton() throws IOException {


        viewButtonMapModalWindow.click();
        SitePageModel.waitFor(1);

        return new RCKenya_GiveBloodDetailsView(driver, giveBloodInfo);

    }


    public RCKenya_EditBloodPage edit() throws IOException {

        editButton.click();

        return new RCKenya_EditBloodPage(driver, giveBloodInfo);

    }

    public RCKenya_GiveBloodListView clickNavigate() {

        navigateButton.click();

        return this;

    }

    public RCKenya_GiveBloodListView assertGoogleMap() {

        SitePageModel.waitFor(1);
        String getTabUrl = SitePageModel.switchTab(driver);
        Assert.assertTrue(getTabUrl.contains("https://www.google.com/maps/dir/"));

        return this;

    }


    public RCKenya_GiveBloodDetailsView openGBCenterDetailsView()
            throws IOException {

        postBodyContent.click();

        return new RCKenya_GiveBloodDetailsView(driver, giveBloodInfo);

    }

    public RCKenya_GiveBloodListView clickSearchIcon() {

        searchIcon.click();

        return this;

    }

    public RCKenya_GiveBloodListView assertSearchField() {

        SitePageModel.waitForVisibilityByElement(driver, searchTextBox);
        SitePageModel.waitForClickabilityByElement(driver, searchTextBox);

        SitePageModel.waitForVisibilityByElement(driver, searchCloseIcon);

        return this;

    }

    public RCKenya_GiveBloodListView sendSearchKeyWord() {

        //SitePageModel.waitFor(1);

        searchTextBox.sendKeys(strTitle);
        SitePageModel.waitFor(2);


        return this;

    }

    public RCKenya_GiveBloodListView sendSearchKeyWordDescription() {

        // SitePageModel.waitFor(1);

        searchTextBox.sendKeys(strDescription);
        SitePageModel.waitFor(2);
        return this;

    }

    public RCKenya_GiveBloodListView closeSearchIcon() {

        searchCloseIcon.click();

        return this;

    }

    public RCKenya_GiveBloodListView assertNothingFoundText() {

        System.out.println(listPostTitle.size());
        SitePageModel.waitForVisibilityByElement(driver, nothingFoundText);

        Assert.assertTrue(nothingFoundText.getText().contains(
                "Nothing was found"));
        // SitePageModel.waitForVisibilityByElement(driver, searchCloseIcon);

        return this;

    }

    public RCKenya_GiveBloodListView assertListViewAfterEditing() {
        //SitePageModel.waitFor(5);
        SitePageModel.waitForVisibilityByElement(driver, postTitle);
        SitePageModel.waitForVisibilityByElement(driver, postDescription);

        Assert.assertTrue(postTitle.getText().contains(strTitle));
        Assert.assertTrue(postDescription.getText().contains(strDescription));


        return this;

    }

    public RCKenya_GiveBloodListView scrollListView() {

        SitePageModel.scrollDownOfPageElement(driver, listScrollElement.get(9));
        SitePageModel.waitFor(1);
        return this;

    }

    public RCKenya_GiveBloodListView assertSearchText() {

        Assert.assertTrue(searchTextBox.getAttribute("value").equals(
                strDescription));
        return this;

    }


}
