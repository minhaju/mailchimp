/**
 * Created by moshiur on 05/10/16.
 */

package com.automation.testClasses;


import com.automation.pageModel.SitePageModel;
import com.automation.util.AppConstant;
import com.automation.util.EmergencyAlertSettings;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.FileNotFoundException;
import java.io.IOException;


public class RCKenya_EmergencyAlert_EditPage {

    public static WebDriver driver;
    EmergencyAlertSettings testDataEmergencyAlert;

    String emergencyAlertName;
    String emergencyAlertDescription;
    String emergencyAlertLink;
    String currentLocation;
    String searchKeyWordName;
    String searchKeyWordDescription;
    String editedEmergencyAlertName;
    String editedEmergencyAlertDescription;


    protected static String strEmergencyAlertRandomNumber = SitePageModel.randomPhoneCode(driver);

    public RCKenya_EmergencyAlert_EditPage(WebDriver driver) {

        RCKenya_EmergencyAlert_EditPage.driver = driver;

        PageFactory.initElements(driver, this);

        testDataEmergencyAlert = new EmergencyAlertSettings();

        emergencyAlertName = testDataEmergencyAlert.getEmergencyAlertName();
        emergencyAlertDescription = testDataEmergencyAlert.getEmergencyAlertDescription();
        emergencyAlertLink = testDataEmergencyAlert.getEmergencyAlertURL();
        currentLocation = testDataEmergencyAlert.getCurrentLocation();
        searchKeyWordName = testDataEmergencyAlert.getSearchKeyWordName();
        searchKeyWordDescription = testDataEmergencyAlert.getSearchKeyWordDescription();
        editedEmergencyAlertName = testDataEmergencyAlert.getEditedEmergencyAlertName();
        editedEmergencyAlertDescription = testDataEmergencyAlert.getEditedEmergencyAlertDescription();
    }

//     String searchKeyWordName2 = "ROOTNEXTalert";
//     String searchKeyWordDescription2 = "RNDescription";

//     String emergencyAlertName = "Test emergency alert "+ strEmergencyAlertName;
//     String emergencyAlertDescription = "Test emergency alert description 4600";
//     String emergencyAlertLink = "https://www.test.com";
//     String currentLocation = "Rd 12, Dhaka, Bangladesh";

//     String editedEmergencyAlertName = "ROOTNEXTalertEdited "+ emergencyAlertName;
//     String editedEmergencyAlertDescription = "RNDescriptionEdited "+ emergencyAlertName;

    @FindBy(how = How.ID, using = "link-left-toggle-create")
    private WebElement newButton;
    @FindBy(how = How.ID, using = "button-new-emergency-cancel")
    private WebElement emergencyAlertFormCancel;
    @FindBy(how = How.ID, using = "field-new-emergency-name")
    private WebElement emergencyAlertNameField;
    @FindBy(how = How.ID, using = "field-new-emergency-description")
    private WebElement emergencyAlertDescriptionField;
    @FindBy(how = How.ID, using = "field-new-emergency-attachments")
    private WebElement emergencyAlertAttachmentField;
    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-my-location ng-scope')]")
    private WebElement emergencyAlertLocationIcon;
    @FindBy(how = How.ID, using = "field-new-emergency-location")
    private WebElement emergencyAlertLocationField;

    @FindBy(how = How.XPATH, using = "//input[contains(@class, 'form-control ng-pristine ng-untouched ng-valid ng-valid-url')]")
    private WebElement emergencyAlertLinkField;
    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-add valid')]")
    private WebElement emergencyAlertLinkConfirmPlus;
    @FindBy(how = How.XPATH, using = "//label[contains(@class, 'control-label') and text()='Featured Story']")
    private WebElement featuredCheckbox;
    @FindBy(how = How.XPATH, using = "//a[contains(@class, 'btn btn-success btn_event btn-wide btn-lg ng-scope') and text()=' Donate']")
    private WebElement donateButton;

    @FindBy(how = How.XPATH, using = "//div[contains(@class,'post-entities-ctrl__title__name ng-binding')]")
    private WebElement alertNameFromDetailPage;
    @FindBy(how = How.XPATH, using = "//p[contains(@class,'ng-binding')]")
    private WebElement alertDescriptionFromDetailPage;
    @FindBy(how = How.XPATH, using = "//a[contains(@class,'ng-binding')]")
    private WebElement alertURLFromDetailPage;
    @FindBy(how = How.XPATH, using = "//div[@class='tooltip-info tooltip-info_left ng-scope']")
    private WebElement hoverQuestionIcon;
    @FindBy(how = How.XPATH, using = "//div[@class='tooltip-info__description']/p")
    private WebElement tooltip;
    @FindBy(how = How.ID, using = "button-new-emergency-edit")
    private WebElement editButton;
    @FindBy(how = How.XPATH, using = "//a[contains(@class, 'btn btn-primary btn-wide btn-lg btn-stroke post-entities-ctrl__edit pull-right ng-scope')]")
    private WebElement editButtonFromDetialPage;
    @FindBy(how = How.XPATH, using = "//span[contains(@class, 'post__actions__text') and text()='Donate']")
    private WebElement donateIcon;
    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-mode-edit')]")
    private WebElement editButtonFromList;
    @FindBy(how = How.ID, using = "button-new-emergency-delete")
    private WebElement deleteButton;
    @FindBy(how = How.XPATH, using = "//button[(@class = 'btn btn-primary btn-wide btn-secondary') and text()='Cancel']")
    private WebElement cancelConfirm;
    @FindBy(how = How.XPATH, using = "//button[(@class = 'btn btn-primary btn-wide') and text()='Delete']")
    private WebElement deleteConfirm;
    @FindBy(how = How.XPATH, using = "//div[@class = 'modal__success']/h4")
    private WebElement deleteConfirmText;


    public RCKenya_EmergencyAlert_EditPage fillEmergencyAlertValue() {

        SitePageModel.waitForVisibilityByElement(driver, emergencyAlertNameField);

        emergencyAlertNameField.clear();
        emergencyAlertNameField.sendKeys(emergencyAlertName);

        emergencyAlertDescriptionField.clear();
        emergencyAlertDescriptionField.sendKeys(emergencyAlertDescription);
        System.out.println(emergencyAlertDescription);

        String strUploadImage = AppConstant.IMAGE_PATH + "testimg1.png";
        emergencyAlertAttachmentField.sendKeys(strUploadImage);
        SitePageModel.waitFor(3);

        emergencyAlertLinkField.clear();
        emergencyAlertLinkField.sendKeys(emergencyAlertLink);
//		SitePageModel.waitFor(2);
        SitePageModel.waitForClickabilityByElement(driver, emergencyAlertLinkConfirmPlus);
        emergencyAlertLinkConfirmPlus.click();

//		SitePageModel.waitFor(2);
        emergencyAlertLocationField.clear();
//        emergencyAlertLocationField.sendKeys(currentLocation);
//        emergencyAlertLocationField.sendKeys(Keys.TAB);

//		SitePageModel.waitFor(2);
        SitePageModel.waitForVisibilityByElement(driver, featuredCheckbox);

        featuredCheckbox.click();

        return this;
    }


    public RCKenya_EmergencyAlert_EditPage assertEmergencyAlertEditButtonActive() {

        SitePageModel.waitForVisibilityByElement(driver, editButton);
        SitePageModel.waitForClickabilityByElement(driver, editButton);
        return this;
    }


    public RCKenya_EmergencyAlert_EditPage assertEmergencyEditCancel() {

        String receivedName = alertNameFromDetailPage.getText();
        Assert.assertEquals(receivedName, emergencyAlertName);

        String receivedDescription = alertDescriptionFromDetailPage.getText();
        Assert.assertEquals(emergencyAlertDescription, receivedDescription);

        return this;
    }

    public RCKenya_EmergencyAlert_EditPage assertEmergencyAlertNotEdited() {

        alertURLFromDetailPage.getText();

        SitePageModel.waitForVisibilityByElement(driver, donateButton);
        SitePageModel.waitForClickabilityByElement(driver, newButton);

        return this;
    }

    public RCKenya_EmergencyAlert_EditPage editEmergencyAlertInfoFromList() {

        emergencyAlertNameField.clear();
        emergencyAlertNameField.sendKeys(editedEmergencyAlertName);
        emergencyAlertDescriptionField.clear();
        emergencyAlertDescriptionField.sendKeys(editedEmergencyAlertDescription);

        editButton.click();
        SitePageModel.waitFor(2);
        return this;
    }


    public RCKenya_EmergencyAlert_EditPage assertEmergencyAlertDetailPage() {

        SitePageModel.waitForVisibilityByElement(driver, donateButton);

        Assert.assertEquals(emergencyAlertName, alertNameFromDetailPage.getText());
        Assert.assertEquals(emergencyAlertDescription, alertDescriptionFromDetailPage.getText());
        Assert.assertEquals(emergencyAlertLink, alertURLFromDetailPage.getText());

        return this;
    }


    public RCKenya_EmergencyAlert_EditPage cancelEmergencyCreationForm() {

        SitePageModel.waitForVisibilityByElement(driver, emergencyAlertFormCancel);
        SitePageModel.waitForClickabilityByElement(driver, emergencyAlertFormCancel);
        emergencyAlertFormCancel.click();
        return this;
    }


    public RCKenya_EmergencyAlert_DetailViewPage editEmergencyAlertInfoFromDetailPage() {

        emergencyAlertNameField.clear();
        emergencyAlertNameField.sendKeys(emergencyAlertName);
        emergencyAlertDescriptionField.clear();
        emergencyAlertDescriptionField.sendKeys(emergencyAlertDescription);

        editButton.click();
        SitePageModel.waitFor(2);
        return new RCKenya_EmergencyAlert_DetailViewPage(driver);
    }


    public RCKenya_EmergencyAlert_EditPage assertEditedInfoFromListPage() {

        SitePageModel.waitForVisibilityByElement(driver, alertNameFromDetailPage);
        SitePageModel.waitForVisibilityByElement(driver, alertDescriptionFromDetailPage);

        Assert.assertEquals(editedEmergencyAlertName, alertNameFromDetailPage.getText());
        Assert.assertEquals(editedEmergencyAlertDescription, alertDescriptionFromDetailPage.getText());

        return this;
    }


    public RCKenya_EmergencyAlert_EditPage clickDeleteButton() {

        deleteButton.click();
        return this;

    }

    public RCKenya_EmergencyAlert_EditPage assertDeleteConfirm() {

        SitePageModel.waitForVisibilityByElement(driver, deleteConfirmText);

        SitePageModel.waitForClickabilityByElement(driver, deleteConfirm);
        deleteConfirm.click();

        return this;
    }

    public RCKenya_EmergencyAlert_EditPage cancelDeleteConfirm() {

        SitePageModel.waitForVisibilityByElement(driver, cancelConfirm);
        SitePageModel.waitForClickabilityByElement(driver, cancelConfirm);
        cancelConfirm.click();
        SitePageModel.waitForVisibilityByElement(driver, donateButton);
        SitePageModel.waitForVisibilityByElement(driver, editButtonFromDetialPage);
        return this;
    }


}
