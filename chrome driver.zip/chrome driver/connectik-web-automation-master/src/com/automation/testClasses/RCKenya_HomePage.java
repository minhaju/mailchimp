package com.automation.testClasses;

import com.automation.pageModel.SitePageModel;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class RCKenya_HomePage {
    public static WebDriver driver;
    String donateInfo;
    String giveBloodInfo = "ss";

    public RCKenya_HomePage(WebDriver driver) {
        RCKenya_HomePage.driver = driver;

        PageFactory.initElements(driver, this);
        this.giveBloodInfo = giveBloodInfo;
    }

    @FindBy(how = How.ID, using = "link-left-menu-foryou")
    private WebElement homeIcon;
    @FindBy(how = How.ID, using = "link-left-toggle-create")
    private WebElement newButton;
    @FindBy(how = How.ID, using = "link-nav-open-user-menu")
    private WebElement userMenu;
    @FindBy(how = How.LINK_TEXT, using = "Profile")
    private WebElement profile;
    @FindBy(how = How.LINK_TEXT, using = "Messages")
    private WebElement messages;
    @FindBy(how = How.LINK_TEXT, using = "Logout")
    private WebElement logout;
//    @FindBy(how = How.XPATH, using = "//button[text()='Logout']")
//     @FindBy(how = How.XPATH, using = "//button[@type='button']")
    @FindBy(how = How.XPATH, using = "//button[@class='btn btn-primary btn-wide btn-additional']")
//    @FindBy(how = How.XPATH, using = "//*[@id='main-view']/modal/div/div/div[2]/button[2]")
    private WebElement logoutConfirm;
    // @FindBy(how = How.ID, using = "link-home-emergencies")
    //  private WebElement buttonEmergencyAlerts;
    @FindBy(how = How.ID, using = "link-home-ambulance")
    private WebElement buttonAmbulance;
    @FindBy(how = How.ID, using = "link-home-give-blood")
    private WebElement buttonGiveBlood;
    @FindBy(how = How.ID, using = "link-home-emergencies")
    private WebElement emergencyTile;
    @FindBy(how = How.XPATH, using = "//a[contains(@ng-click, 'createEmergency') and text()='Emergency Alert']")
    private WebElement emergencyAlertCreationIcon;
    @FindBy(how = How.ID, using = "link-home-donate")
    private WebElement buttonDonate;

    public RCKenya_HomePage assertHomePage() {
        //SitePageModel.waitFor(4);
        SitePageModel.waitForVisibilityByElement(driver, homeIcon);
        SitePageModel.waitForVisibilityByElement(driver, newButton);
        SitePageModel.waitForVisibilityByElement(driver, userMenu);
        SitePageModel.waitForVisibilityByElement(driver, buttonAmbulance);
        SitePageModel.waitForVisibilityByElement(driver, buttonDonate);
        SitePageModel.waitForVisibilityByElement(driver, buttonGiveBlood);
        return this;
    }


    public RCKenya_HomePage openUserMenu() {

        SitePageModel.waitFor(1);
        userMenu.click();
        SitePageModel.waitFor(1);

        return this;
    }

    public RCKenya_HomePage assertUserMenu() {

        SitePageModel.waitForClickabilityByElement(driver, profile);
        SitePageModel.waitForClickabilityByElement(driver, messages);
        SitePageModel.waitForClickabilityByElement(driver, logout);

        return this;
    }

    public RCKenya_HomePage selectLogout() {

        logout.click();
        SitePageModel.waitFor(2);
        return this;
    }

    public RCKenya_HomePage assertSelectLogout() {

        SitePageModel.waitForClickabilityByElement(driver, logoutConfirm);

        return this;

    }

    public RCKenya_HomePage clickLogoutConfirm() {

        logoutConfirm.click();

        SitePageModel.waitFor(2);

        return this;

    }

    public RCKenya_Donate clickDonate() {

        buttonDonate.click();
        return new RCKenya_Donate(driver, donateInfo);

    }

    public RCKenya_GiveBloodListView clickGiveBlood(String giveBloodInfo) throws IOException {

        buttonGiveBlood.click();
        return new RCKenya_GiveBloodListView(driver, giveBloodInfo);

    }

    public RCKenya_HomePage assertMemberShipPage() {

        SitePageModel.waitForVisibilityByElement(driver, homeIcon);
        SitePageModel.waitForVisibilityByElement(driver, newButton);

        String expectedURL = "https://dev-members-ken.rc-app.com/membership/individual/";
        String getURL = driver.getCurrentUrl();

        Assert.assertTrue(getURL.equals(expectedURL));

        return this;

    }

    public RCKenya_HomePage clickCreateNew() {

        newButton.click();

        return this;

    }

    public RCKenya_HomePage assertNewButton() {

        SitePageModel.waitForVisibilityByElement(driver, newButton);

        return this;
    }

    public RCKenya_HomePage assertEmergencyTile() {

        SitePageModel.waitForVisibilityByElement(driver, emergencyTile);

        return this;
    }


    public RCKenya_EmergencyAlert_ListViewPage clickEmergencyTile() {

        SitePageModel.waitForClickabilityByElement(driver, emergencyTile);
        SitePageModel.waitFor(2);
        emergencyTile.click();

        return new RCKenya_EmergencyAlert_ListViewPage(driver);
    }

    public RCKenya_HomePage navigateToHomeURL() {

        SitePageModel.navigateToSpecificPage(driver, "https://dev-members-ken.rc-app.com");

        return this;

    }

    public RCKenya_HomePage clickNewButton() {

        SitePageModel.waitFor(1);
        SitePageModel.waitForClickabilityByElement(driver, newButton);
        newButton.click();

        return this;
    }

    public RCKenya_HomePage openEmergencyAlertCreationForm() {

        SitePageModel.waitForVisibilityByElement(driver, emergencyAlertCreationIcon);
        emergencyAlertCreationIcon.click();

        return this;
    }

}
