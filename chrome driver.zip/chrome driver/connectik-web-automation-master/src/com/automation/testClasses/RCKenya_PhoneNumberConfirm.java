package com.automation.testClasses;

import com.automation.pageModel.SitePageModel;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.awt.*;

public class RCKenya_PhoneNumberConfirm {

    public static WebDriver driver;
    RCKenya_EnterPhoneNumber enterPhoneNumber;

    String strRndPhoneText;
    String strPhoneText;
    String userType;

    public RCKenya_PhoneNumberConfirm(WebDriver driver, String userType) {
        RCKenya_PhoneNumberConfirm.driver = driver;
        //this.userType=userType;
        PageFactory.initElements(driver, this);
        this.userType = userType;
        enterPhoneNumber = new RCKenya_EnterPhoneNumber(driver, userType);
 
		
		/*
         * We use RCKenya_EnterPhoneNumber instance because of the testcases for edit phone number.
		 * As phone number needs for edit
		 * 
		 */


        strRndPhoneText = RCKenya_EnterPhoneNumber.strRndPhoneNumber;
        strPhoneText = enterPhoneNumber.strPhoneNumber;
    }

    // @FindBy(how = How.XPATH, using = "//button/translate/span[contains(@class, 'ng-scope') and text()='Yes']")
    // private WebElement yesButton;
    @FindBy(how = How.XPATH, using = "//button[(@class='btn btn-wide btn-primary') and @type='submit']")
    private WebElement yesButton;
    @FindBy(how = How.XPATH, using = "//button[(@class='btn btn-wide btn_stroke') and @type='button']")

    private WebElement editButton;

    //////translate/span[(@class, 'ng-scope') and text()='Edit']")
    @FindBy(how = How.XPATH, using = "//translate/span[contains(@class, 'ng-scope') and text()='Is your mobile phone number below correct?']")
    private WebElement validationText;
    @FindBy(how = How.XPATH, using = " .//*[@id='main-view']/div/div/div[2]/form/div/h3")
    private WebElement phoneText;
    @FindBy(how = How.ID, using = "field-phone")
    private WebElement mobileNumber;
    @FindBy(how = How.XPATH, using = "//button[@type='submit']")
    private WebElement loginBtn;

    public RCKenya_PhoneNumberConfirm assertPhoneNumberConfirm() {
        SitePageModel.waitForVisibilityByElement(driver, validationText);
        SitePageModel.waitForVisibilityByElement(driver, yesButton);
        SitePageModel.waitForVisibilityByElement(driver, editButton);
        Assert.assertTrue(phoneText.getText().contains(strPhoneText));

        return this;
    }

    public RCKenya_PhoneNumberConfirm assertRandomPhoneNumber() {
        SitePageModel.waitForVisibilityByElement(driver, yesButton);
        SitePageModel.waitForVisibilityByElement(driver, editButton);
        Assert.assertTrue(phoneText.getText().contains(strRndPhoneText));

        return this;
    }

    public RCKenya_PhoneCode phoneNumberConfirm() {
        yesButton.click();

        return new RCKenya_PhoneCode(driver);
    }

    public RCKenya_PhoneCode confirmLoginInfoByEnter() throws AWTException {

        SitePageModel.clickButtonByRobotClass();

        return new RCKenya_PhoneCode(driver);
    }

    public RCKenya_PhoneNumberConfirm assertPhoneNumberFieldActive() {

        SitePageModel.waitForVisibilityByElement(driver, mobileNumber);
        SitePageModel.waitForClickabilityByElement(driver, mobileNumber);
        return this;
    }

    public RCKenya_EnterPhoneNumber editPhoneNumber() {
        editButton.click();

        //return new RCKenya_EnterPhoneNumber(driver, strPhoneText);
        return new RCKenya_EnterPhoneNumber(driver, userType);

    }

    public RCKenya_PhoneNumberConfirm assertLoginButtonActive() {

        SitePageModel.waitForClickabilityByElement(driver, loginBtn);

        return this;
    }

}
