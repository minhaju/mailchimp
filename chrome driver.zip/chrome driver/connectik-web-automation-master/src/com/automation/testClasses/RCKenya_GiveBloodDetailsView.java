package com.automation.testClasses;

import com.automation.pageModel.SitePageModel;
import com.automation.util.GiveBloodSettings;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

//import java.util.Set;
//import com.automation.util.DonateSettings;
//import com.automation.util.LoginSettings;

public class RCKenya_GiveBloodDetailsView {
    public static WebDriver driver;
    GiveBloodSettings testDataGiveBloodDetailsView;
    String giveBloodInfo;

    String strTitle;
    String strDescription;
    String strLinks;
    String strCoverPhoto;
    String strAttachment;
    @FindBy(how = How.XPATH, using = "//div[@class='post-entities-ctrl__title__name ng-binding']")
    private WebElement postTitleName;
    @FindBy(how = How.XPATH, using = "//div[@class='post-entities-ctrl__info__description']/p")
    private WebElement postDescription;
    @FindBy(how = How.XPATH, using = "//div[@class='post-entities-ctrl__sidebar']/div/h3")
    private WebElement creatorName;
    @FindBy(how = How.XPATH, using = "//div[@class='post-entities-ctrl__info__links ng-scope']/ul/li/a")
    private WebElement links;
    @FindBy(how = How.XPATH, using = "//file-miniature[@class='ng-pristine ng-untouched ng-valid ng-isolate-scope']/div/a/div/div[1]")
    private WebElement attachment;
    @FindBy(how = How.LINK_TEXT, using = "Send Message")
    private WebElement buttonSendMessage;
    @FindBy(how = How.LINK_TEXT, using = "EDIT")
    private WebElement editButton;
    @FindBy(how = How.XPATH, using = "//div[@class='staticGoogleMap__navigate ng-scope']/a")
    private WebElement navigateButton;
    @FindBy(how = How.XPATH, using = "//ui-gmap-google-map/div/div[1]/div/div[4]/div/div[2]/a")
    private WebElement googleMap;

    public RCKenya_GiveBloodDetailsView(WebDriver driver, String giveBloodInfo)
            throws IOException {
        RCKenya_GiveBloodDetailsView.driver = driver;

        PageFactory.initElements(driver, this);
        this.giveBloodInfo = giveBloodInfo;
        testDataGiveBloodDetailsView = new GiveBloodSettings(giveBloodInfo);
        strTitle = testDataGiveBloodDetailsView.getTitle();
        strDescription = testDataGiveBloodDetailsView.getDescription();
        strLinks = testDataGiveBloodDetailsView.getLinks();
        strCoverPhoto = testDataGiveBloodDetailsView.getCoverPhoto();
        strAttachment = testDataGiveBloodDetailsView.getAttachment();

    }

    public RCKenya_GiveBloodDetailsView assertGiveBloodDetailsView() {
        SitePageModel.waitFor(8);
        SitePageModel.waitForVisibilityByElement(driver, postTitleName);
        //SitePageModel.waitForVisibilityByElement(driver, postDescription);
        SitePageModel.waitForVisibilityByElement(driver, creatorName);
        // SitePageModel.waitForVisibilityByElement(driver, buttonSendMessage);

        SitePageModel.waitForVisibilityByElement(driver, navigateButton);

        SitePageModel.waitForVisibilityByElement(driver, editButton);


        return this;
    }

    public RCKenya_EditBloodPage edit() throws IOException {

        editButton.click();

        return new RCKenya_EditBloodPage(driver, giveBloodInfo);

    }

    public RCKenya_GiveBloodMapTab clickNavigate() {

        navigateButton.click();

        return new RCKenya_GiveBloodMapTab(driver);

    }

    public RCKenya_GiveBloodDetailsView assertGiveBloodDetailsViewInfo() {

        SitePageModel.waitForVisibilityByElement(driver, postTitleName);
        Assert.assertTrue(postTitleName.getText().contains(strTitle));


        SitePageModel.waitForVisibilityByElement(driver, postDescription);
        Assert.assertTrue(postDescription.getText().contains(strDescription));

        SitePageModel.waitForVisibilityByElement(driver, links);
        Assert.assertTrue(links.getText().contains(strLinks));

        SitePageModel.waitForVisibilityByElement(driver, attachment);
        Assert.assertTrue(attachment.getText().contains(strAttachment));

        return this;
    }

    public RCKenya_GiveBloodDetailsView assertGiveBloodDetailsViewAfterEdit() {

        SitePageModel.waitForVisibilityByElement(driver, postTitleName);
        Assert.assertTrue(postTitleName.getText().contains(strTitle));
        SitePageModel.waitForVisibilityByElement(driver, postDescription);
        Assert.assertTrue(postDescription.getText().contains(strDescription));
        SitePageModel.waitForVisibilityByElement(driver, links);
        Assert.assertTrue(links.getText().contains(strLinks));
        SitePageModel.waitForVisibilityByElement(driver, attachment);
        Assert.assertTrue(attachment.getText().contains(strAttachment));

        return this;
    }

}
