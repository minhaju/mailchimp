/**
 * Created by moshiur on 05/10/16.
 */

package com.automation.testClasses;


import com.automation.pageModel.SitePageModel;
import com.automation.util.EmergencyAlertSettings;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;


public class RCKenya_EmergencyAlert_DetailViewPage {

    public static WebDriver driver;
    EmergencyAlertSettings testDataEmergencyAlert;

    String emergencyAlertName;
    String emergencyAlertDescription;
    String emergencyAlertLink;
    String currentLocation;
    String searchKeyWordName;
    String searchKeyWordDescription;
    String editedEmergencyAlertName;
    String editedEmergencyAlertDescription;


    protected static String strEmergencyAlertRandomNumber = SitePageModel.randomPhoneCode(driver);

    public RCKenya_EmergencyAlert_DetailViewPage(WebDriver driver) {

        RCKenya_EmergencyAlert_DetailViewPage.driver = driver;

        PageFactory.initElements(driver, this);

        testDataEmergencyAlert = new EmergencyAlertSettings();

        emergencyAlertName = testDataEmergencyAlert.getEmergencyAlertName();
        emergencyAlertDescription = testDataEmergencyAlert.getEmergencyAlertDescription();
        emergencyAlertLink = testDataEmergencyAlert.getEmergencyAlertURL();
        currentLocation = testDataEmergencyAlert.getCurrentLocation();
        searchKeyWordName = testDataEmergencyAlert.getSearchKeyWordName();
        searchKeyWordDescription = testDataEmergencyAlert.getSearchKeyWordDescription();
        editedEmergencyAlertName = testDataEmergencyAlert.getEditedEmergencyAlertName();
        editedEmergencyAlertDescription = testDataEmergencyAlert.getEditedEmergencyAlertDescription();
    }

//     String searchKeyWordName2 = "ROOTNEXTalert";
//     String searchKeyWordDescription2 = "RNDescription";

//     String emergencyAlertName = "Test emergency alert "+ strEmergencyAlertName;
//     String emergencyAlertDescription = "Test emergency alert description 4600";
//     String emergencyAlertLink = "https://www.test.com";
//     String currentLocation = "Rd 12, Dhaka, Bangladesh";

//     String editedEmergencyAlertName = "ROOTNEXTalertEdited "+ emergencyAlertName;
//     String editedEmergencyAlertDescription = "RNDescriptionEdited "+ emergencyAlertName;


    @FindBy(how = How.ID, using = "field-new-emergency-name")
    private WebElement emergencyAlertNameField;
    @FindBy(how = How.ID, using = "field-new-emergency-description")
    private WebElement emergencyAlertDescriptionField;
    @FindBy(how = How.XPATH, using = "//a[contains(@class, 'btn btn-success btn_event btn-wide btn-lg ng-scope') and text()=' Donate']")
    private WebElement donateButton;
    @FindBy(how = How.XPATH, using = "//div[contains(@class,'post-entities-ctrl__title__name ng-binding')]")
    private WebElement alertNameFromDetailPage;
    @FindBy(how = How.XPATH, using = "//p[contains(@class,'ng-binding')]")
    private WebElement alertDescriptionFromDetailPage;
    @FindBy(how = How.XPATH, using = "//a[contains(@class,'ng-binding')]")
    private WebElement alertURLFromDetailPage;
    @FindBy(how = How.XPATH, using = "//div[@class='tooltip-info tooltip-info_left ng-scope']")
    private WebElement hoverQuestionIcon;
    @FindBy(how = How.XPATH, using = "//div[@class='tooltip-info__description']/p")
    private WebElement tooltip;
    @FindBy(how = How.ID, using = "button-new-emergency-edit")
    private WebElement editButton;
    @FindBy(how = How.XPATH, using = "//a[contains(@class, 'btn btn-primary btn-wide btn-lg btn-stroke post-entities-ctrl__edit pull-right ng-scope')]")
    private WebElement editButtonFromDetialPage;

    @FindBy(how = How.ID, using = "button-new-emergency-delete")
    private WebElement deleteButton;
    @FindBy(how = How.XPATH, using = "//button[(@class = 'btn btn-primary btn-wide btn-secondary') and text()='Cancel']")
    private WebElement cancelConfirm;
    @FindBy(how = How.XPATH, using = "//button[(@class = 'btn btn-primary btn-wide') and text()='Delete']")
    private WebElement deleteConfirm;
    @FindBy(how = How.XPATH, using = "//div[@class = 'modal__success']/h4")
    private WebElement deleteConfirmText;
    @FindBy(how = How.XPATH, using = "//span[(@class = 'one-word ng-binding')]")
    private WebElement alertCreatorName;
    @FindBy(how = How.XPATH, using = "//img[(@class = 'ng-scope img-circle')]")
    private WebElement alertCreatorAvatarIcon;
    @FindBy(how = How.XPATH, using = "//div[(@class = 'staticGoogleMap__navigate ng-scope')]")
    private WebElement alertNavigateButton;
    @FindBy(how = How.XPATH, using = "//i[(@class = 'md md-favorite')]")
    private WebElement HeartIconDonateCreationPage;


    public RCKenya_EmergencyAlert_DetailViewPage assertEmergencyAlertDetailPage() {

        SitePageModel.waitForVisibilityByElement(driver, donateButton);

        Assert.assertEquals(emergencyAlertName, alertNameFromDetailPage.getText());
        Assert.assertEquals(emergencyAlertDescription, alertDescriptionFromDetailPage.getText());
        Assert.assertEquals(emergencyAlertLink, alertURLFromDetailPage.getText());

        return this;
    }


    public RCKenya_EmergencyAlert_DetailViewPage getAlertInfoFromDetailPage() {

        SitePageModel.waitForVisibilityByElement(driver, alertNameFromDetailPage);
        SitePageModel.waitForVisibilityByElement(driver, alertDescriptionFromDetailPage);
        SitePageModel.waitForVisibilityByElement(driver, donateButton);
        SitePageModel.waitForVisibilityByElement(driver, editButtonFromDetialPage);
        SitePageModel.waitForVisibilityByElement(driver, alertCreatorName);
        SitePageModel.waitForVisibilityByElement(driver, alertCreatorAvatarIcon);
//		SitePageModel.waitForVisibilityByElement(driver, alertNavigateButton);
//		SitePageModel.waitForVisibilityByElement(driver, distanceIcon);

        return this;
    }

    public RCKenya_EmergencyAlert_DetailViewPage clickDonateButtonFromDetailPage() {

        donateButton.click();

        SitePageModel.waitForVisibilityByElement(driver, HeartIconDonateCreationPage);

        return this;
    }

    public RCKenya_EmergencyAlert_EditPage clickEditFromDetailPage() {

        editButtonFromDetialPage.click();
        SitePageModel.waitFor(2);

        return new RCKenya_EmergencyAlert_EditPage(driver);
    }


    public RCKenya_EmergencyAlert_DetailViewPage assertEditedInfoFromDetailPage() {

        SitePageModel.waitForVisibilityByElement(driver, alertNameFromDetailPage);
        SitePageModel.waitForVisibilityByElement(driver, alertDescriptionFromDetailPage);

        Assert.assertEquals(emergencyAlertName, alertNameFromDetailPage.getText());
        Assert.assertEquals(emergencyAlertDescription, alertDescriptionFromDetailPage.getText());

        return this;
    }


    public RCKenya_EmergencyAlert_DetailViewPage clickDeleteButton() {

        deleteButton.click();
        return this;

    }

    public RCKenya_EmergencyAlert_DetailViewPage assertDeleteConfirm() {

        SitePageModel.waitForVisibilityByElement(driver, deleteConfirmText);

        SitePageModel.waitForClickabilityByElement(driver, deleteConfirm);
        deleteConfirm.click();

        return this;
    }

    public RCKenya_EmergencyAlert_DetailViewPage cancelDeleteConfirm() {

        SitePageModel.waitForVisibilityByElement(driver, cancelConfirm);
        SitePageModel.waitForClickabilityByElement(driver, cancelConfirm);
        cancelConfirm.click();
        SitePageModel.waitForVisibilityByElement(driver, donateButton);
        SitePageModel.waitForVisibilityByElement(driver, editButtonFromDetialPage);
        return this;
    }


}
