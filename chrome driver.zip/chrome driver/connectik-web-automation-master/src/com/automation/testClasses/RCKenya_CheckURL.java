package com.automation.testClasses;

/**
 * Created by sayedul on 10/25/16.
 */

import com.automation.pageModel.SitePageModel;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.awt.*;


public class RCKenya_CheckURL {
    public static WebDriver driver;


    public RCKenya_CheckURL(WebDriver driver) {
        RCKenya_CheckURL.driver = driver;
        PageFactory.initElements(driver, this);


    }

    public static String checkCurrentURL(String userType) throws InterruptedException, AWTException {
        String staffUser = "staff";

        String loginPage;
        String otherPage;

        //  SitePageModel.waitFor(2);
        String curURL = SitePageModel.getCurrentURL(driver);
        if (curURL.contains("https://dev-members-ken.rc-app.com/login")) {
            loginPage = "loginPage";
            return loginPage;
        } else {

            otherPage = "otherPage";
            return otherPage;
        }
     }

    public static String checkCurrentStatus(String userType) throws InterruptedException, AWTException {
        String staffUser = "staff";

        String loginPage;
        String otherPage;

//          SitePageModel.waitFor(12);
        String curURL = SitePageModel.getCurrentURL(driver);
        if (curURL.contains("https://dev-members-ken.rc-app.com/login")) {
            loginPage = "loginPage";
            return loginPage;
        } else {

            otherPage = "otherPage";
            return otherPage;
        }
    }

}
