package com.automation.testClasses;


import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.automation.pageModel.SitePageModel;
import com.automation.util.DonateSettings;
import com.automation.util.LoginSettings;


public class RCKenya_DonateConfirm {

    public static WebDriver driver;
    DonateSettings testDataDonate;

    String strDonationAmount;
    String strPaymentMethod;
    String strCardType;
    String strCardNumber;
    String strCardExpiryMonth;
    String strCardExpiryYear;
    String strCVV;

    public RCKenya_DonateConfirm(WebDriver driver, String donateInfo) {
        RCKenya_DonateConfirm.driver = driver;

        PageFactory.initElements(driver, this);

        testDataDonate = new DonateSettings(donateInfo);
        //strDonationAmount=testDataDonate.getDonationAmount();
        //strPaymentMethod=testDataDonate.getPaymentMethod();
        //strCardType=testDataDonate.getCardType();
        strCardNumber = testDataDonate.getCardNumber();
        //strCardExpiryMonth=testDataDonate.getCardExpiryMonth();
        //strCardExpiryYear=testDataDonate.getCardExpiryYear();
        //strCVV=testDataDonate.getCVV();

    }

    //@FindBy(how = How.XPATH, using= "//div[@class='create-donation__receiver__tooltip__icon']") private WebElement hoverQuestionIcon;
    @FindBy(how = How.XPATH, using = "//span[@class='edit-payment']")
    private WebElement editDonation;
    //	@FindBy(how = How.ID, using= "select-donation-payment") private WebElement paymentMethod;
    @FindBy(how = How.XPATH, using = "//input[@class = 'braintree__field form-control card-number ng-pristine ng-untouched ng-valid']")
    private WebElement inputtedCardNumber;
    @FindBy(how = How.ID, using = "button-pay")
    private WebElement buttonConfirm;
    @FindBy(how = How.XPATH, using = "//div[@class='create-donation__modal__success']/h3")
    private WebElement paymentCompletePopUpText;
    @FindBy(how = How.XPATH, using = "//div[@class='thanks-text ng-scope']/h3")
    private WebElement thankNote;


    public RCKenya_DonateConfirm assertDonateConfirm() {
        //String expectedToolTipTitle="Make a difference be the difference";
        SitePageModel.waitForVisibilityByElement(driver, editDonation);

        SitePageModel.waitForVisibilityByElement(driver, inputtedCardNumber);
        SitePageModel.waitForVisibilityByElement(driver, buttonConfirm);
        //SitePageModel.waitForVisibilityByElement(driver, buttonConfirm);
        //SitePageModel.waitForVisibilityByElement(driver, buttonConfirm);

        //System.out.println(editDonation.getText());
        Assert.assertTrue(editDonation.getText().equals("EDIT"));
        String expectedCardNumber = "**** **** *** **" + strCardNumber.substring(strCardNumber.length() - 2);

        String displayedCardNumber = inputtedCardNumber.getAttribute("value");

        //System.out.println(strCardNumber.substring(strCardNumber.length()-2));
        Assert.assertTrue(displayedCardNumber.equals(expectedCardNumber));


        //driver.switchTo().frame(inputtedCardNumber);
        //System.out.println(inputtedCardNumber.getAttribute("value"));
        //System.out.println(inputtedCardNumber.isDisplayed());
        Assert.assertTrue(inputtedCardNumber.isDisplayed());
        Assert.assertFalse(inputtedCardNumber.isEnabled());
        //driver.switchTo().defaultContent();
        //String text = ((JavaScriptExecutor)driver).executeScript("return $(arguments[0]).text();", element);
        Assert.assertTrue(buttonConfirm.isDisplayed());
        Assert.assertTrue(buttonConfirm.isEnabled());

        return this;

    }

    public RCKenya_DonateConfirm clickConfirmButton() {

        buttonConfirm.click();
        SitePageModel.waitFor(2);
        return this;

    }

    public RCKenya_DonateConfirm assertPaymentComplete() {

        SitePageModel.waitForVisibilityByElement(driver, paymentCompletePopUpText);
        SitePageModel.waitForVisibilityByElement(driver, thankNote);

        Assert.assertTrue(paymentCompletePopUpText.getText().contains("Payment Completed"));
        Assert.assertTrue(thankNote.getText().contains("Thank you"));

        SitePageModel.waitFor(2);
        return this;

    }
}
