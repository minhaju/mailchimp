package com.automation.testClasses;


//import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.automation.pageModel.SitePageModel;

public class RCKenya_VoiceCallCode {
    public static WebDriver driver;

    public RCKenya_VoiceCallCode(WebDriver driver) {
        RCKenya_VoiceCallCode.driver = driver;

        PageFactory.initElements(driver, this);
    }

    @FindBy(how = How.ID, using = "field-voice-code")
    private WebElement voiceCode;
    @FindBy(how = How.XPATH, using = "//button[@class='btn btn-primary btn-lg']")
//    @FindBy(how = How.XPATH, using = "//button[contains(@class, 'btn btn-primary btn-lg')")
//    @FindBy(how = How.XPATH, using = "//translate[contains(@class, 'ng-scope') and text()='Call Me']")
    private WebElement callMeButton;

    public RCKenya_VoiceCallCode assertVoiceCodePage() {

        SitePageModel.waitForVisibilityByElement(driver, callMeButton);
        SitePageModel.waitForVisibilityByElement(driver, voiceCode);

        return this;
    }

    public RCKenya_VoiceCallCode clickCallMeButton() {
        callMeButton.click();

        return this;
    }

    public RCKenya_HomePage enterVoiceCode() {

        voiceCode.sendKeys(SitePageModel.maskLoginCodes(driver));
        return new RCKenya_HomePage(driver);
    }

}


