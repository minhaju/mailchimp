package com.automation.testClasses;

//import java.util.List;

import com.automation.pageModel.SitePageModel;
import com.automation.util.AppConstant;
import com.automation.util.GiveBloodSettings;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

//import org.openqa.selenium.interactions.Actions;
//import com.automation.util.DonateSettings;

//import com.automation.util.LoginSettings;

public class RCKenya_EditBloodPage {
    public static WebDriver driver;
    GiveBloodSettings editTestDataGiveBlood;

    String giveBloodInfo;
    String strTitle;

    String strDescription;
    // String cardType;
    String strCoverPhoto;
    String strAttachment;
    String strLinks;
    String strLocation;

    public RCKenya_EditBloodPage(WebDriver driver, String giveBloodInfo) throws IOException {
        RCKenya_EditBloodPage.driver = driver;

        PageFactory.initElements(driver, this);
        this.giveBloodInfo = giveBloodInfo;
        editTestDataGiveBlood = new GiveBloodSettings(giveBloodInfo);
        strTitle = editTestDataGiveBlood.getTitle();
        strDescription = editTestDataGiveBlood.getDescription();
        strLinks = editTestDataGiveBlood.getLinks();
        strCoverPhoto = editTestDataGiveBlood.getCoverPhoto();
        strAttachment = editTestDataGiveBlood.getAttachment();
    }

    @FindBy(how = How.ID, using = "field-new-give-blood-name")
    private WebElement titleGiveBlood;
    @FindBy(how = How.ID, using = "field-new-give-blood-description")
    private WebElement descriptionGiveBlood;
    @FindBy(how = How.CLASS_NAME, using = "input-upload__file")
    private WebElement coverPhotoGiveBlood;
    @FindBy(how = How.ID, using = "field-new-give-blood-attachments")
    private WebElement attachmentGiveBlood;
    @FindBy(how = How.NAME, using = "link")
    private WebElement linksTextBox;
    @FindBy(how = How.XPATH, using = "//i[@class='md md-add valid']")
    private WebElement plusLinkButton;
    //FindBy(how = How.XPATH, using = "//i/preceding-sibling::input[@name='link']")
    //private WebElement plusLinkButton;
    //@FindBy(how = How.XPATH, using = ".//*[@id='main-view']/create-post-entity/div/div/div/form/div[5]/input-links/div/div/i")
    // private WebElement plusLinkButton;

    @FindBy(how = How.XPATH, using = "//i[contains(@class, 'md md-my-location ng-scope')]")
    private WebElement giveBloodLocationIcon;
    @FindBy(how = How.ID, using = "button-new-give-blood-edit")
    private WebElement editGiveBloodButton;
    @FindBy(how = How.ID, using = "button-new-give-blood-delete")
    private WebElement deleteButton;
    @FindBy(how = How.ID, using = "button-new-give-blood-cancel")
    private WebElement cancelButton;
    @FindBy(how = How.XPATH, using = "//div[@class = 'modal__success']/h4")
    private WebElement deleteConfirmText;
    @FindBy(how = How.XPATH, using = "//button[(@class = 'btn btn-primary btn-wide') and text()='Delete']")
    private WebElement deleteConfirm;
    @FindBy(how = How.XPATH, using = "//button[(@class = 'btn btn-primary btn-wide btn-secondary') and text()='Cancel']")
    private WebElement cancelConfirm;
    @FindBy(how = How.XPATH, using = "//input-links[@class='ng-isolate-scope']/div/ul/li[1]/i")
    private WebElement closeLink;
    @FindBy(how = How.XPATH, using = "//input-upload[@class='ng-pristine ng-untouched ng-valid ng-isolate-scope']/div/ul/li[1]/a/i")
    private WebElement closeAttchment;

    public RCKenya_EditBloodPage assertEditWindow() {
        // SitePageModel.waitFor(7);

        SitePageModel.waitForVisibilityByElement(driver, titleGiveBlood);
        SitePageModel.waitForVisibilityByElement(driver, descriptionGiveBlood);


        if (!coverPhotoGiveBlood.isEnabled()) {
            SitePageModel.waitFor(5);
        }
        Assert.assertTrue(coverPhotoGiveBlood.isEnabled());

        if (!attachmentGiveBlood.isEnabled()) {
            SitePageModel.waitFor(5);
        }

        Assert.assertTrue(attachmentGiveBlood.isEnabled());
        SitePageModel.waitForClickabilityByElement(driver, linksTextBox);

        //  SitePageModel.waitForVisibilityByElement(driver, deleteButton);
        SitePageModel.waitForVisibilityByElement(driver, cancelButton);
        SitePageModel.waitForVisibilityByElement(driver, editGiveBloodButton);

        // SitePageModel.waitFor(5);
        return this;

    }


    public RCKenya_EditBloodPage editFormDataWithoutLink() {

        titleGiveBlood.clear();
        titleGiveBlood.sendKeys(strTitle);
        descriptionGiveBlood.clear();
        descriptionGiveBlood.sendKeys(strDescription);
        coverPhotoGiveBlood.sendKeys(AppConstant.IMAGE_PATH + strCoverPhoto);
        attachmentGiveBlood.clear();
        attachmentGiveBlood.sendKeys(AppConstant.IMAGE_PATH + strAttachment);
        closeAttchment.click();

        linksTextBox.sendKeys(strLinks);
        return this;

    }

    public RCKenya_EditBloodPage AssertOtherFieldData() {

        //SitePageModel.waitForVisibilityByElement(driver, descriptionGiveBlood);

        SitePageModel.waitForVisibilityByElement(driver, plusLinkButton);
        SitePageModel.waitForClickabilityByElement(driver, closeLink);

        return this;

    }

    public RCKenya_EditBloodPage enterOtherData() {

        SitePageModel.waitFor(2);
        plusLinkButton.click();
        closeLink.click();

        return this;

    }


    public RCKenya_EditBloodPage clickCancelEdit() {


        cancelButton.click();

        return this;

    }

    public RCKenya_EditBloodPage clickDeleteButton() {

        deleteButton.click();

        return this;

    }

    public RCKenya_EditBloodPage asserDeletePopuPWindow() {

        SitePageModel.waitForClickabilityByElement(driver, deleteConfirmText);

        SitePageModel.waitForVisibilityByElement(driver, deleteConfirm);
        SitePageModel.waitForVisibilityByElement(driver, cancelConfirm);

        Assert.assertTrue(deleteConfirmText.getText().contains("Are you sure?"));

        return this;

    }

    public RCKenya_EditBloodPage CancelDeletePopup() {

        cancelConfirm.click();

        return this;

    }

    public RCKenya_GiveBloodListView clickDeleteConfirmPopup() throws IOException {

        deleteConfirm.click();

        return new RCKenya_GiveBloodListView(driver, giveBloodInfo);

    }

    public RCKenya_GiveBloodListView clickEditButton() throws IOException {

        editGiveBloodButton.click();
        SitePageModel.waitFor(2);
        return new RCKenya_GiveBloodListView(driver, giveBloodInfo);

    }

}