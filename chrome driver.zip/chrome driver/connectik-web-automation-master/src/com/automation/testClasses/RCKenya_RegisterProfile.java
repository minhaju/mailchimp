package com.automation.testClasses;

import com.automation.pageModel.SitePageModel;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

//import com.automation.testClasses.RCKenya_PhoneNumberConfirm;
//import com.automation.testClasses.RCKenya_EnterPhoneNumber;
//import com.automation.util.LoginSettings;


public class RCKenya_RegisterProfile {

    public static WebDriver driver;


    public RCKenya_RegisterProfile(WebDriver driver) {
        RCKenya_RegisterProfile.driver = driver;

        PageFactory.initElements(driver, this);

    }

    @FindBy(how = How.NAME, using = "firstName")
    private WebElement fName;
    @FindBy(how = How.NAME, using = "lastName")
    private WebElement lName;
//    @FindBy(how = How.XPATH, using = "//button[@type='submit']")
    @FindBy(how = How.XPATH, using = ".//*[@id='main-view']/div/div/div[5]/form/div/div[2]/button")
//    @FindBy(how = How.XPATH, using = "//button[(@class='btn btn-wide btn-primary btn-lg') and text()='Done']")
    private WebElement doneButton;

    public RCKenya_RegisterProfile assertRegistrationProfilePage() {


        SitePageModel.waitForVisibilityByElement(driver, fName);
        SitePageModel.waitForVisibilityByElement(driver, lName);

        return this;
    }

    public RCKenya_RegisterProfile enterRequiredField() {


        fName.sendKeys("test");
        lName.sendKeys("coc");


        return this;
    }

    public RCKenya_RegisterProfile assertDoneButton() {

        SitePageModel.waitForVisibilityByElement(driver, doneButton);

        return this;

    }

    public RCKenya_MembershipPage clickDoneButton() {

        SitePageModel.waitForClickabilityByElement(driver, doneButton);
        SitePageModel.waitFor(2);

        doneButton.click();
        return new RCKenya_MembershipPage(driver);
    }
}
