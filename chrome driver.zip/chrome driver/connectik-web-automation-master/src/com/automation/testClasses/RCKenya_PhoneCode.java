package com.automation.testClasses;

import com.automation.pageModel.SitePageModel;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RCKenya_PhoneCode {
    public static WebDriver driver;

    protected static String strRndPhoneCode = SitePageModel.randomPhoneCode(driver);


    public RCKenya_PhoneCode(WebDriver driver) {
        RCKenya_PhoneCode.driver = driver;

        PageFactory.initElements(driver, this);
    }

    @FindBy(how = How.ID, using = "field-phone-code")
    private WebElement phoneCode;
    @FindBy(how = How.XPATH, using = "//translate/span[contains(@class, 'ng-scope') and text()='Voice Verification']")
    private WebElement voiceVerificationLink;
    @FindBy(how = How.XPATH, using = "//form[contains(@name, 'enterCodeForm')]/div/div[2]/p")
    private WebElement validationMessage;

    public RCKenya_PhoneCode assertPhoneCode() {

        SitePageModel.waitForVisibilityByElement(driver, voiceVerificationLink);
        SitePageModel.waitForVisibilityByElement(driver, phoneCode);
        SitePageModel.waitForClickabilityByElement(driver, phoneCode);
        return this;
    }

    public RCKenya_PhoneCode enterWrongPhoneCode() {

        phoneCode.sendKeys(strRndPhoneCode);

        return this;
    }

    public RCKenya_PhoneCode assertWrongPhoneCode() {
        SitePageModel.waitFor(2);
        SitePageModel.waitForVisibilityByElement(driver, validationMessage);
        return this;
    }

    public RCKenya_HomePage enterPhoneCode() {

        phoneCode.clear();
        phoneCode.sendKeys(SitePageModel.maskLoginCodes(driver));

        return new RCKenya_HomePage(driver);
    }

    public RCKenya_RegisterProfile enterPhoneCodeFirstLogin() {

        phoneCode.clear();
        phoneCode.sendKeys(SitePageModel.maskLoginCodes(driver));

        return new RCKenya_RegisterProfile(driver);
    }

    public RCKenya_PhoneCode clickVoiceVerificationLink() {

        voiceVerificationLink.click();

        return this;
    }
}
