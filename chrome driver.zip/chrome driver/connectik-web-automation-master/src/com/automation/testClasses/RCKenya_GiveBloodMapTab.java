package com.automation.testClasses;

//import java.util.ArrayList;
//import java.util.List;
//import java.util.Set;

//import java.util.Set;

import com.automation.pageModel.SitePageModel;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.How;
//import com.automation.util.DonateSettings;
//import com.automation.util.LoginSettings;

public class RCKenya_GiveBloodMapTab {
    public static WebDriver driver;

    public RCKenya_GiveBloodMapTab(WebDriver driver) {
        RCKenya_GiveBloodMapTab.driver = driver;

        PageFactory.initElements(driver, this);

    }

    // @FindBy(how = How.ID, using= "field-donation-amount") private WebElement
    // donationAmount;

    public RCKenya_GiveBloodMapTab assertGoogleMap() {

        String getTabUrl = SitePageModel.switchTab(driver);
        Assert.assertTrue(getTabUrl.contains("https://www.google.com/maps/"));

        return this;

    }

}
