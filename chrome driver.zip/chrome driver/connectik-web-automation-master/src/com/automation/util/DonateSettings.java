package com.automation.util;

import java.io.FileInputStream;
import java.util.Properties;

//import com.automation.pageModel.SitePageModel;
import com.automation.util.AppConstant;

public class DonateSettings {

    String donationAmount;

    String paymentMethod;
    //String cardType;
    String cardNumber;
    String cardExpiryMonth;
    String cardExpiryYear;
    String cvv;

    public DonateSettings(String donateInfo) {
        Properties donateProp = null;

        try {
            donateProp = new Properties();

            donateProp.load(new FileInputStream(AppConstant.SETTING_DONATE_PATH));
            setDonationAmount(donateProp.getProperty("donationAmount"));
            setPaymentMethod(donateProp.getProperty("paymentMethod"));
            setCardNumber(donateProp.getProperty("cardNumber"));
            setCardExpiryMonth(donateProp.getProperty("cardExpiryMonth"));
            setCardExpiryYear(donateProp.getProperty("cardExpiryYear"));
            setCVV(donateProp.getProperty("cvv"));

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public String getDonationAmount() {
        return donationAmount;
    }

    public void setDonationAmount(String donationAmount) {
        this.donationAmount = donationAmount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }


    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardExpiryMonth() {
        return cardExpiryMonth;
    }

    public void setCardExpiryMonth(String cardExpiryMonth) {
        this.cardExpiryMonth = cardExpiryMonth;
    }

    public String getCardExpiryYear() {
        return cardExpiryYear;
    }

    public void setCardExpiryYear(String cardExpiryYear) {
        this.cardExpiryYear = cardExpiryYear;
    }


    public String getCVV() {
        return cvv;
    }

    public void setCVV(String cvv) {
        this.cvv = cvv;
    }

}
