package com.automation.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class EmergencyAlertSettings {

    private String strEmergencyAlertName;
    private String strEmergencyAlertDescription;
    private String strEmergencyAlertURL;
    private String strCurrentLocation;
    private String strSearchKeywordName;
    private String strSearchKeywordDescription;
    private String strEditedEmergencyAlertName;
    private String strEditedEmergencyAlertDescription;

    public EmergencyAlertSettings() {
        Properties emergencyAlertProp = null;


        try {
        emergencyAlertProp = new Properties();
        emergencyAlertProp.load(new FileInputStream(AppConstant.SETTING_EMERGENCYALERT_PATH));

        setEmergencyAlertName(emergencyAlertProp.getProperty("emergencyAlertName"));
        setEmergencyAlertDescription(emergencyAlertProp.getProperty("emergencyAlertDescription"));
        setEmergencyAlertURL(emergencyAlertProp.getProperty("emergencyAlertURL"));
        setCurrentLocation(emergencyAlertProp.getProperty("currentLocation"));
        setSearchKeyWordName(emergencyAlertProp.getProperty("searchKeyWordName"));
        setSearchKeyWordDescription(emergencyAlertProp.getProperty("searchKeyWordDescription"));
        setEditedEmergencyAlertName(emergencyAlertProp.getProperty("editedEmergencyAlertName"));
        setEditedEmergencyAlertDescription(emergencyAlertProp.getProperty("editedEmergencyAlertDescription"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public String getEmergencyAlertName() {
        return strEmergencyAlertName;
    }

    public void setEmergencyAlertName(String emergencyAlertName) {
        this.strEmergencyAlertName = emergencyAlertName;
    }

    public String getEmergencyAlertDescription() {
        return strEmergencyAlertDescription;
    }

    public void setEmergencyAlertDescription(String emergencyAlertDescription) {
        this.strEmergencyAlertDescription = emergencyAlertDescription;
    }

    public String getEmergencyAlertURL() {
        return strEmergencyAlertURL;
    }

    public void setEmergencyAlertURL(String emergencyAlertURL) {
        this.strEmergencyAlertURL = emergencyAlertURL;
    }

    public String getCurrentLocation() {
        return strCurrentLocation;
    }

    public void setCurrentLocation(String currentLocation) {
        this.strCurrentLocation = currentLocation;
    }

    public String getSearchKeyWordName() {
        return strSearchKeywordName;
    }

    public void setSearchKeyWordName(String searchKeyWordName) {
        this.strSearchKeywordName = searchKeyWordName;
    }

    public String getSearchKeyWordDescription() {
        return strSearchKeywordDescription;
    }

    public void setSearchKeyWordDescription(String searchKeyWordDescription) {
        this.strSearchKeywordDescription = searchKeyWordDescription;
    }

    public String getEditedEmergencyAlertName() {
        return strEditedEmergencyAlertName;
    }

    public void setEditedEmergencyAlertName(String editedEmergencyAlertName) {
        this.strEditedEmergencyAlertName = editedEmergencyAlertName;
    }


    public String getEditedEmergencyAlertDescription() {
        return strEditedEmergencyAlertDescription;
    }

    public void setEditedEmergencyAlertDescription(String editedEmergencyAlertDescription) {
        this.strEditedEmergencyAlertDescription = editedEmergencyAlertDescription;
    }

}
