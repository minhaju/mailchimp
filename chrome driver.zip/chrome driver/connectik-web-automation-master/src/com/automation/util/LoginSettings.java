package com.automation.util;

import java.io.FileInputStream;
import java.util.Properties;

import com.automation.pageModel.SitePageModel;
import com.automation.util.AppConstant;

public class LoginSettings {

    private String countryCode;
    private String phoneNumber;
    private String fullPhoneNumber;
    private String getUserType;

    public LoginSettings(String userType) {
        Properties loginProp = null;

        try {
            loginProp = new Properties();
            getUserType = userType;

            // System.out.println (userType);
            if (getUserType.equals("staff")) {
                loginProp.load(new FileInputStream(
                        AppConstant.SETTING_LOGIN_PATH));
                // loginProp.load(new
                // FileInputStream(AppConstant.SETTING_GUEST_LOGIN_PATH));

            }

            if (getUserType.equals("guest")) {
                // loginProp.load(new
                // FileInputStream(AppConstant.SETTING_LOGIN_PATH));
                loginProp.load(new FileInputStream(
                        AppConstant.SETTING_GUEST_LOGIN_PATH));

            }

            if (getUserType.equals("firstuser")) {
                // loginProp.load(new
                // FileInputStream(AppConstant.SETTING_LOGIN_PATH));
                loginProp.load(new FileInputStream(
                        AppConstant.SETTING_NEWUSE_LOGIN_PATH));

            }
            // this.countryCode = loginProp.getProperty("countryCode");
            // this.phoneNumber = loginProp.getProperty("phoneNumber");
            setcountryCode(loginProp.getProperty("countryCode"));
            setPhoneNUmber(loginProp.getProperty("phoneNumber"));
            setFullPhoneNumber(getCountryCode(), getPhoneNumber());

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public String fullPhoneNumber() {
        return fullPhoneNumber;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setcountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setFullPhoneNumber(String countryCode, String phoneNumber) {
        this.fullPhoneNumber = SitePageModel.parseCountryCode(countryCode)
                + phoneNumber;
    }

    public String getFullPhoneNumber() {
        return fullPhoneNumber;
    }

    public void setPhoneNUmber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

}
