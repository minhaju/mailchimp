package com.automation.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.automation.util.AppConstant;

public class GiveBloodSettings {

    String title;

    String description;
    // String cardType;
    String coverPhoto;
    String attachment;
    String links;
    String location;
    String giveBloodInfo;


    public GiveBloodSettings(String giveBloodInfo) {
        Properties giveBloodProp = null;

       // System.out.println(giveBloodInfo+"ss1");
        try {
            giveBloodProp = new Properties();
            this.giveBloodInfo=giveBloodInfo;
           // System.out.println(giveBloodInfo+"ss21");
            giveBloodProp.load(new FileInputStream(AppConstant.CURRENT_DIR
                    + "/testdata/" + giveBloodInfo));
         //   System.out.println(giveBloodInfo+"ss3");
            setTitle(giveBloodProp.getProperty("title"));
            setDescription(giveBloodProp.getProperty("description"));
            setCoverPhoto(giveBloodProp.getProperty("coverPhoto"));
            setAttachment(giveBloodProp.getProperty("attachments"));
            setLinks(giveBloodProp.getProperty("links"));

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public String getTitle() {

        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCoverPhoto() {
        return coverPhoto;
    }

    public void setCoverPhoto(String coverPhoto) {
        this.coverPhoto = coverPhoto;
    }

    public String getAttachment() {
        return attachment;
    }

    public void setAttachment(String attachment) {
        this.attachment = attachment;
    }

    public String getLinks() {
        return links;
    }

    public void setLinks(String links) {
        this.links = links;
    }

}
